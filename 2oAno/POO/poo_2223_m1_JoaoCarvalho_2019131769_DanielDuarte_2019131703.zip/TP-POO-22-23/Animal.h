//
// Created by João Carvalho on 07/11/2022.
//

#ifndef TP_POO_22_23_ANIMAL_H
#define TP_POO_22_23_ANIMAL_H

#include <iostream>
#include <sstream>
#include <string.h>
#include <cstdlib>
#include <sstream>

using namespace std;

class Animal{
public:
    Animal(char& abreviation, int y, int x);

    ~Animal();

    char getAbreviation() const;
    int getID() const;
    string getAnimalAsString() const;
    int getX() const;
    int getY() const;

    void setID(int number);
    void setX(int number);
    void setY(int number);
    void setInitialHealth(char abrv);
    void setLTime(char abrv);

    static void setAbreviation(string animalType, string character);
    static void setLife(string animalType, int health);
    static void setLifeTime(string animalType, int moments);
private:
    static string NCoelho;
    static int SCoelho;
    static int VCoelho;
    static string NOvelha;
    static int SOvelha;
    static int VOvelha;
    static string NLobo;
    static int SLobo;
    static int VLobo;
    static string NCanguru;
    static int SCanguru;
    static int VCanguru;
    static string NMisterio;
    static int SMisterio;
    static int VMisterio;

    char abreviation;
    int id;
    int initialHealth;
    int minHealth;
    int maxHealth;
    int health;
    int lifeTime;
    int starvingPoints;

    int y;
    int x;
};

#endif //TP_POO_22_23_ANIMAL_H

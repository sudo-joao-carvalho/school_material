//
// Created by João Carvalho on 07/11/2022.
//

//Duvida, ler o fich constantes e onde se mete os valores que recebe

#include "Interface.h"
#include "Reserva.h"
#include <fstream>

Interface::~Interface(){
    delete r;
}

void Interface::readConstantes(vector<string> sepCommands) {

        for(int i = 0; i < sepCommands.size(); i++){
            if(sepCommands[0].substr(0, 1) == "N"){
                Animal::setAbreviation(sepCommands[0], sepCommands[1]);
            }

            if(sepCommands[0].substr(0, 1) == "S"){
                Animal::setLife(sepCommands[0], stoi(sepCommands[1]));
            }

            if(sepCommands[0].substr(0, 1) == "V"){
                Animal::setLifeTime(sepCommands[0], stoi(sepCommands[1]));
            }
        }

        //cout << "Ficheiro de constantes lido" << endl;
}

void Interface::commandAnimal(vector<string> sepCommands){
    if(sepCommands.size() <= 2){
        if(isNumber(sepCommands[0])){
            return ;
        }else if(isNumber(sepCommands[1])){
            return ;
        }

        if(sepCommands[1] == "c"){ //c o l g m
            //PASSAR COORDENADAS RANDOM QUANDO N SAO DADAS PELO USER
            int y = 0;
            int x = 0;
            y = rand() % r->getNL() + 1;
            x = rand() % r->getNC() + 1;
            r->criaAnimal((char&) sepCommands[1], y, x);
            //PASSAR COORDENADAS RANDOM QUANDO N SAO DADAS PELO USER

            /*for(int i = 0; i < r->getAnimalVector().size(); i++){
                cout << r->getAnimalVector()[i]->getAbreviation() << " " << r->getAnimalVector()[i]->getY() << " " << r->getAnimalVector()[i]->getX();
            }*/

            return ;
        }

        if(sepCommands[1] == "o"){
            //PASSAR COORDENADAS RANDOM QUANDO N SAO DADAS PELO USER
            int y = 0;
            int x = 0;
            y = rand() % r->getNL() + 1;
            x = rand() % r->getNC() + 1;
            r->criaAnimal((char&) sepCommands[1], y, x);
            //PASSAR COORDENADAS RANDOM QUANDO N SAO DADAS PELO USER

            /*for(int i = 0; i < r->getAnimalVector().size(); i++){
                cout << r->getAnimalVector()[i]->getAbreviation() << " " << r->getAnimalVector()[i]->getY() << " " << r->getAnimalVector()[i]->getX();
            }*/

            return ;
        }else if(sepCommands[1] == "l"){
            //PASSAR COORDENADAS RANDOM QUANDO N SAO DADAS PELO USER
            int y = 0;
            int x = 0;
            y = rand() % r->getNL() + 1;
            x = rand() % r->getNC() + 1;
            r->criaAnimal((char&) sepCommands[1], y, x);
            //PASSAR COORDENADAS RANDOM QUANDO N SAO DADAS PELO USER

            /*for(int i = 0; i < r->getAnimalVector().size(); i++){
                cout << r->getAnimalVector()[i]->getAbreviation() << " " << r->getAnimalVector()[i]->getY() << " " << r->getAnimalVector()[i]->getX();
            }*/

            return ;
        }else if(sepCommands[1] == "g"){
            //PASSAR COORDENADAS RANDOM QUANDO N SAO DADAS PELO USER
            int y = 0;
            int x = 0;
            y = rand() % r->getNL() + 1;
            x = rand() % r->getNC() + 1;
            r->criaAnimal((char&) sepCommands[1], y, x);
            //PASSAR COORDENADAS RANDOM QUANDO N SAO DADAS PELO USER

            /*for(int i = 0; i < r->getAnimalVector().size(); i++){
                cout << r->getAnimalVector()[i]->getAbreviation() << " " << r->getAnimalVector()[i]->getY() << " " << r->getAnimalVector()[i]->getX();
            }*/

            return ;
        }else if(sepCommands[1] == "m"){
            //PASSAR COORDENADAS RANDOM QUANDO N SAO DADAS PELO USER
            int y = 0;
            int x = 0;
            y = rand() % r->getNL() + 1;
            x = rand() % r->getNC() + 1;
            r->criaAnimal((char&) sepCommands[1], y, x);
            //PASSAR COORDENADAS RANDOM QUANDO N SAO DADAS PELO USER

            /*for(int i = 0; i < r->getAnimalVector().size(); i++){
                cout << r->getAnimalVector()[i]->getAbreviation() << " " << r->getAnimalVector()[i]->getY() << " " << r->getAnimalVector()[i]->getX();
            }*/

            return ;
        }else
            cout << "[ERRO] Tipo de alimento errado";


    }

    if(sepCommands.size() > 2){
        if(isNumber(sepCommands[0])){
            return ;
        }else if(isNumber(sepCommands[1])){
            return ;
        }else if(!isNumber(sepCommands[2])){
            return ;
        }else if(!isNumber(sepCommands[3])){
            return ;
        }

        if(sepCommands[1] == "c"){ //c o l g m
            r->criaAnimal((char&) sepCommands[1], stoi(sepCommands[2]), stoi(sepCommands[3]));
            /*for(int i = 0; i < r->getAnimalVector().size(); i++){
                cout << r->getAnimalVector()[i]->getAbreviation() << " " << r->getAnimalVector()[i]->getY() << " " << r->getAnimalVector()[i]->getX();
            }*/

            return ;
        }else if(sepCommands[1] == "o"){
            r->criaAnimal((char&) sepCommands[1], stoi(sepCommands[2]), stoi(sepCommands[3]));
            /*for(int i = 0; i < r->getAnimalVector().size(); i++){
                cout << r->getAnimalVector()[i]->getAbreviation() << " " << r->getAnimalVector()[i]->getY() << " " << r->getAnimalVector()[i]->getX();
            }*/

            return ;
        }else if(sepCommands[1] == "l"){
            r->criaAnimal((char&) sepCommands[1], stoi(sepCommands[2]), stoi(sepCommands[3]));
            /*for(int i = 0; i < r->getAnimalVector().size(); i++){
                cout << r->getAnimalVector()[i]->getAbreviation() << " " << r->getAnimalVector()[i]->getY() << " " << r->getAnimalVector()[i]->getX();
            }*/
        }else if(sepCommands[1] == "g"){
            r->criaAnimal((char&) sepCommands[1], stoi(sepCommands[2]), stoi(sepCommands[3]));
            /*for(int i = 0; i < r->getAnimalVector().size(); i++){
                cout << r->getAnimalVector()[i]->getAbreviation() << " " << r->getAnimalVector()[i]->getY() << " " << r->getAnimalVector()[i]->getX();
            }*/

            return ;
        }else if(sepCommands[1] == "m"){
            r->criaAnimal((char&) sepCommands[1], stoi(sepCommands[2]), stoi(sepCommands[3]));
            /*for(int i = 0; i < r->getAnimalVector().size(); i++){
                cout << r->getAnimalVector()[i]->getAbreviation() << " " << r->getAnimalVector()[i]->getY() << " " << r->getAnimalVector()[i]->getX();
            }*/

            return ;
        }else
            cout << "[ERRO] Tipo de animal errado";
    }
}

void Interface::commandKill(vector<string> sepCommands){
    if(sepCommands.size() < 3){
        if(isNumber(sepCommands[0])){
            return ;
        }else if(!isNumber(sepCommands[1])){
            return ;
        }
    }

    if(sepCommands.size() == 3){
        if(isNumber(sepCommands[0])){
            return ;
        }else if(!isNumber(sepCommands[1])){
            return ;
        }else if(!isNumber(sepCommands[2])){
            return ;
        }
    }

}

void Interface::commandFood(vector<string> sepCommands){
    if(sepCommands.size() <= 2){
        if(isNumber(sepCommands[0])){
            return ;
        }else if(isNumber(sepCommands[1])){
            return ;
        }

        if(sepCommands[1] == "r"){//r t b a
            //PASSAR COORDENADAS RANDOM QUANDO N SAO DADAS PELO USER
            int y = 0;
            int x = 0;
            y = rand() % r->getNL() + 1;
            x = rand() % r->getNC() + 1;
            r->criaAlimento((char&) sepCommands[1], y, x);
            //PASSAR COORDENADAS RANDOM QUANDO N SAO DADAS PELO USER

            /*for(int i = 0; i < r->getAlimentoVector().size(); i++){
                cout << r->getAlimentoVector()[i]->getAbreviation() << " " << r->getAlimentoVector()[i]->getY() << " " << r->getAlimentoVector()[i]->getX();
            }*/

            return ;
        }

        if(sepCommands[1] == "t"){//r t b a
            //PASSAR COORDENADAS RANDOM QUANDO N SAO DADAS PELO USER
            int y = 0;
            int x = 0;
            y = rand() % r->getNL() + 1;
            x = rand() % r->getNC() + 1;
            r->criaAlimento((char&) sepCommands[1], y, x);
            //PASSAR COORDENADAS RANDOM QUANDO N SAO DADAS PELO USER

            /*for(int i = 0; i < r->getAlimentoVector().size(); i++){
                cout << r->getAlimentoVector()[i]->getAbreviation() << " " << r->getAlimentoVector()[i]->getY() << " " << r->getAlimentoVector()[i]->getX();
            }*/

            return ;
        }

        if(sepCommands[1] == "b"){//r t b a
            //PASSAR COORDENADAS RANDOM QUANDO N SAO DADAS PELO USER
            int y = 0;
            int x = 0;
            y = rand() % r->getNL() + 1;
            x = rand() % r->getNC() + 1;
            r->criaAlimento((char&) sepCommands[1], y, x);
            //PASSAR COORDENADAS RANDOM QUANDO N SAO DADAS PELO USER

            /*for(int i = 0; i < r->getAlimentoVector().size(); i++){
                cout << r->getAlimentoVector()[i]->getAbreviation() << " " << r->getAlimentoVector()[i]->getY() << " " << r->getAlimentoVector()[i]->getX();
            }*/

            return ;
        }

        if(sepCommands[1] == "a"){//r t b a
            //PASSAR COORDENADAS RANDOM QUANDO N SAO DADAS PELO USER
            int y = 0;
            int x = 0;
            y = rand() % r->getNL() + 1;
            x = rand() % r->getNC() + 1;
            r->criaAlimento((char&) sepCommands[1], y, x);
            //PASSAR COORDENADAS RANDOM QUANDO N SAO DADAS PELO USER

            /*for(int i = 0; i < r->getAlimentoVector().size(); i++){
                cout << r->getAlimentoVector()[i]->getAbreviation() << " " << r->getAlimentoVector()[i]->getY() << " " << r->getAlimentoVector()[i]->getX();
            }*/

            return ;
        }

        cout << "[ERRO] Tipo de alimento errado";
    }

    if(sepCommands.size() > 2){
        if(isNumber(sepCommands[0])){
            return ;
        }else if(isNumber(sepCommands[1])){
            return ;
        }else if(!isNumber(sepCommands[2])){
            return ;
        }else if(!isNumber(sepCommands[3])){
            return ;
        }

        if(sepCommands[1] == "r"){//r t b a
            r->criaAlimento((char&) sepCommands[1], stoi(sepCommands[2]), stoi(sepCommands[3]));

            /*for(int i = 0; i < r->getAlimentoVector().size(); i++){
                cout << r->getAlimentoVector()[i]->getAbreviation() << " " << r->getAlimentoVector()[i]->getY() << " " << r->getAlimentoVector()[i]->getX();
            }*/

            return;
        }

        if(sepCommands[1] == "t"){//r t b a
            r->criaAlimento((char&) sepCommands[1], stoi(sepCommands[2]), stoi(sepCommands[3]));

            /*for(int i = 0; i < r->getAlimentoVector().size(); i++){
                cout << r->getAlimentoVector()[i]->getAbreviation() << " " << r->getAlimentoVector()[i]->getY() << " " << r->getAlimentoVector()[i]->getX();
            }*/

            return;
        }

        if(sepCommands[1] == "b"){//r t b a
            r->criaAlimento((char&) sepCommands[1], stoi(sepCommands[2]), stoi(sepCommands[3]));

            /*for(int i = 0; i < r->getAlimentoVector().size(); i++){
                cout << r->getAlimentoVector()[i]->getAbreviation() << " " << r->getAlimentoVector()[i]->getY() << " " << r->getAlimentoVector()[i]->getX();
            }*/

            return ;
        }

        if(sepCommands[1] == "a"){//r t b a
            r->criaAlimento((char&) sepCommands[1], stoi(sepCommands[2]), stoi(sepCommands[3]));

            /*for(int i = 0; i < r->getAlimentoVector().size(); i++){
                cout << r->getAlimentoVector()[i]->getAbreviation() << " " << r->getAlimentoVector()[i]->getY() << " " << r->getAlimentoVector()[i]->getX();
            }*/

            return ;
        }

        cout << "[ERRO] Tipo de alimento errado";
    }
}

void Interface::commandFeed(vector<string> sepCommands) {
    if(sepCommands.size() == 5){
        if(isNumber(sepCommands[0])){
            return ;
        }else if(!isNumber(sepCommands[1])){
            return ;
        }else if(!isNumber(sepCommands[2])){
            return ;
        }else if(!isNumber(sepCommands[3])){
            return ;
        }else if(!isNumber(sepCommands[4])){
            return ;
        }
    }
}

void Interface::commandFeedID(vector<string> sepCommands) {
    if(sepCommands.size() == 4){
        if(isNumber(sepCommands[0])){
            return ;
        }else if(!isNumber(sepCommands[1])){
            return ;
        }else if(!isNumber(sepCommands[2])){
            return ;
        }else if(!isNumber(sepCommands[3])){
            return ;
        }
    }
}

void Interface::commandNoFood(vector<string> sepCommands) {
    if(sepCommands.size() == 3){
        if(isNumber(sepCommands[0])){
            return ;
        }else if(!isNumber(sepCommands[1])){
            return ;
        }else if(!isNumber(sepCommands[2])){
            return ;
        }
    }

    if(sepCommands.size() == 2){
        if(isNumber(sepCommands[0])){ //string
            return ;
        }else if(!isNumber(sepCommands[1])){ //numero
            return ;
        }
    }
}

void Interface::commandEmpty(vector<string> sepCommands){
    if(sepCommands.size() == 3){
        if(isNumber(sepCommands[0])){
            return ;
        }else if(!isNumber(sepCommands[1])){
            return ;
        }else if(!isNumber(sepCommands[2])){
            return ;
        }
    }
}

void Interface::commandSee(vector<string> sepCommands){
    if(sepCommands.size() == 3){
        if(isNumber(sepCommands[0])){
            return ;
        }else if(!isNumber(sepCommands[1])){
            return ;
        }else if(!isNumber(sepCommands[2])){
            return ;
        }
    }

    cout << endl << endl << "[COMANDO SEE]" << endl << endl;

    cout << "Posicao (" << sepCommands[1] << "," << sepCommands[2] << ")" << endl << endl;
    if(!r->getAnimalVector().empty()){
        cout << "Animais: " << endl;
        for(auto a: r->getAnimalVector()){
            if(a->getY() == stoi(sepCommands[1]) && a->getX() == stoi(sepCommands[2])){
                cout << a->getAnimalAsString();
                cout << "------------------------" << endl;
            }
        }
    }
    if(!r->getAlimentoVector().empty()){
        cout << "Alimentos: " << endl;
        for(auto a: r->getAlimentoVector()){
            if(a->getY() == stoi(sepCommands[1]) && a->getX() == stoi(sepCommands[2])){
                cout << a->getAlimentosAsString();
                cout << "------------------------" << endl;
            }
        }
    }
}

void Interface::commandInfo(vector<string> sepCommands){
    if(sepCommands.size() == 2){
        if(isNumber(sepCommands[0])){
            return ;
        }else if(!isNumber(sepCommands[1])){
            return ;
        }
    }

    cout << endl << endl << "[COMANDO INFO]" << endl << endl;

    for(auto a : r->getAnimalVector()){
        if(a->getID() == stoi(sepCommands[1])){
            cout << a->getAnimalAsString();
        }
    }

    for(auto a : r->getAlimentoVector()){
        if(a->getID() == stoi(sepCommands[1])){
            cout << a->getAlimentosAsString();
        }
    }
}

void Interface::commandNext(vector<string> sepCommands){
    if(sepCommands.size() == 1){
        if(isNumber(sepCommands[0])){
            return ;
        }
    }

    if(sepCommands.size() == 2){
        if(isNumber(sepCommands[0])){
            return ;
        }else if(!isNumber(sepCommands[1])){
            return ;
        }
    }

    if(sepCommands.size() == 3){
        if(isNumber(sepCommands[0])){
            return ;
        }else if(!isNumber(sepCommands[1])){
            return ;
        }else if(!isNumber(sepCommands[2])){
            return ;
        }
    }
}

void Interface::commandAnim(vector<string> sepCommands) {
    if (sepCommands.size() == 1) {
        if (isNumber(sepCommands[0])) {
            return;
        }
    }

    cout << endl << endl << "[COMANDO ANIM]" << endl << endl;
    cout << r->getAnimalVectorAsString();
}

void Interface::commandVisAnim(vector<string> sepCommands){
    if (sepCommands.size() == 1) {
        if (isNumber(sepCommands[0])) {
            return;
        }
    }
}

void Interface::commandStore(vector<string> sepCommands){
    if(sepCommands.size() == 2){
        if(isNumber(sepCommands[0])){
            return ;
        }else if(isNumber(sepCommands[1])){
            return ;
        }
    }
}

void Interface::commandReStore(vector<string> sepCommands){
    if(sepCommands.size() == 2){
        if(isNumber(sepCommands[0])){
            return ;
        }else if(isNumber(sepCommands[1])){
            return ;
        }
    }
}

void Interface::commandLoad(vector<string> sepCommands){
    if(sepCommands.size() == 2){
        if(isNumber(sepCommands[0])){
            return ;
        }else if(isNumber(sepCommands[1])){
            return ;
        }
    }
}

void Interface::commandSlide(vector<string> sepCommands){
    if(sepCommands.size() == 3){
        if(isNumber(sepCommands[0])){
            return ;
        }else if(isNumber(sepCommands[1])){
            return ;
        }else if(!isNumber(sepCommands[2])){
            return ;
        }
    }
}

void Interface::commandExit(vector<string> sepCommands){
    if (sepCommands.size() == 1) {
        if (isNumber(sepCommands[0])) {
            return;
        }
    }

    exit(0);
}

vector<string> Interface::divideString(string str) const{
    string aux;

    stringstream ss(str);

    vector<string> palavras;

    while (getline(ss, aux, ' ')){
        palavras.push_back(aux);
    }

    return palavras;
}

bool Interface::isNumber(const string& str) {
    for(int i = 0; i < str.size(); i++){
        if(isdigit(str[i]) == true)
            return true;
    }

    return false;
}

void Interface::loadCommandsFromKeyboard(string line) {

    vector<string> separatedCommands = divideString(line);
    commandsV.push_back(line);

    if(separatedCommands[0] == "animal"){
        commandAnimal(separatedCommands);
    }

    if(separatedCommands[0] == "kill"){
        commandKill(separatedCommands);
    }

    if(separatedCommands[0] == "food"){
        commandFood(separatedCommands);
    }

    if(separatedCommands[0] == "feed"){
        commandFeed(separatedCommands);
    }

    if(separatedCommands[0] == "feedid"){
        commandFeedID(separatedCommands);
    }

    if(separatedCommands[0] == "nofood"){
        commandNoFood(separatedCommands);
    }

    if(separatedCommands[0] == "empty"){
        commandEmpty(separatedCommands);
    }

    if(separatedCommands[0] == "see"){
        commandSee(separatedCommands);
    }

    if(separatedCommands[0] == "info"){
        commandInfo(separatedCommands);
    }

    if(separatedCommands[0] == "n"){
        commandNext(separatedCommands);
    }

    if(separatedCommands[0] == "anim"){
        commandAnim(separatedCommands);
    }

    if(separatedCommands[0] == "visanim"){
        commandVisAnim(separatedCommands);
    }

    if(separatedCommands[0] == "store"){
        commandStore(separatedCommands);
    }

    if(separatedCommands[0] == "restore"){
        commandReStore(separatedCommands);
    }

    if(separatedCommands[0] == "load"){
        loadCommandsFromFile(separatedCommands[1]);
    }

    if(separatedCommands[0] == "slide"){
        commandSlide(separatedCommands);
    }

    if(separatedCommands[0] == "exit"){
        commandExit(separatedCommands);
    }

}

void Interface::loadCommandsFromFile(const string& filename) {

    ifstream file(filename);

    if(file.is_open() && file.good()){
        string line;

        while(getline(file, line) || !file.eof()){
            vector<string> separatedCommands = divideString(line);
            commandsV.push_back(line);

            if(separatedCommands[0] == "animal"){
                commandAnimal(separatedCommands);
            }

            if(separatedCommands[0] == "kill"){
                commandKill(separatedCommands);
            }

            if(separatedCommands[0] == "food"){
                commandFood(separatedCommands);
            }

            if(separatedCommands[0] == "feed"){
                commandFeed(separatedCommands);
            }

            if(separatedCommands[0] == "feedid"){
                commandFeedID(separatedCommands);
            }

            if(separatedCommands[0] == "nofood"){
                commandNoFood(separatedCommands);
            }

            if(separatedCommands[0] == "empty"){
                commandEmpty(separatedCommands);
            }

            if(separatedCommands[0] == "see"){
                commandSee(separatedCommands);
            }

            if(separatedCommands[0] == "info"){
                commandInfo(separatedCommands);
            }

            if(separatedCommands[0] == "n"){
                commandNext(separatedCommands);
            }

            if(separatedCommands[0] == "anim"){
                commandAnim(separatedCommands);
            }

            if(separatedCommands[0] == "visanim"){
                commandVisAnim(separatedCommands);
            }

            if(separatedCommands[0] == "store"){
                commandStore(separatedCommands);
            }

            if(separatedCommands[0] == "restore"){
                commandReStore(separatedCommands);
            }

            /*if(separatedCommands[0] == "load"){
                commandLoad(separatedCommands);
            }*/

            if(separatedCommands[0] == "slide"){
                commandSlide(separatedCommands);
            }

            if(separatedCommands[0] == "exit"){
                commandExit(separatedCommands);
            }

            readConstantes(separatedCommands);
        }
    }

}

void Interface::board(){

    cout << "\n\n\t\t\t\t========================================" << endl;
    cout << "\t\t\t\t=\t\t\t\tRESERVA\t\t\t\t   =\t\t" << endl;
    cout << "\t\t\t\t========================================" << endl;

    for(int a = 0; a < r->getNL(); a++){
        int j;

        cout << endl;
        cout << "*";
        for(int b = 0; b < r->getNC(); b++) {
            for (int i = 0; i < 8; i++) {
                cout << "*";
            }
        }

        //1a LINHA VAZIA
        cout << endl;
        for(int b = 0; b < r->getNC(); b++) {
            cout << "*" << a + 1 << "," << b + 1 << "";
            //cout << "*       ";
            /*for(int i = 0; i < num_spaces; i++){
                cout << " ";
            }*/
            if((a + 1) < 10 && (b + 1) < 10){
                cout << "    ";
            }else if((a + 1) < 10 && (b + 1) >= 10 && (b + 1) < 100){
                cout << "   ";
            }else if((a + 1) < 10 && (b + 1) > 100){
                cout << "  ";
            }else if((a + 1) >= 10 && (b + 1) < 100 && (b + 1) < 10){
                cout << "   ";
            }else if((a + 1) >= 10 && (a + 1) < 100 && (b + 1) >= 10 && (b + 1) < 100){
                cout << "  ";
            }else if((a + 1) >= 10 && (b + 1) < 100 && (b + 1) >= 100){
                cout << " ";
            }else if((a + 1) >= 100 && (b + 1) < 10){
                cout << "  ";
            }else if((a + 1) >= 100 && (b + 1) > 10 && (b + 1) < 100){
                cout << " ";
            }else
                continue;
        }
        cout << "*";
        cout << endl;
        //1a LINHA VAZIA

        //LINHA DOS ANIMAIS
        for(int b = 0; b < r->getNC(); b++) {
            cout << "*";
            int num_animals_space = 0;
            int num_spaces = 7;
            for(int c = 0; c < r->getAnimalVector().size(); c++){
                if(r->getAnimalVector()[c]->getY() == (a + 1) && r->getAnimalVector()[c]->getX() == (b + 1)){
                    cout << r->getAnimalVector()[c]->getAbreviation();
                    ++num_animals_space;
                    --num_spaces;
                }
            }

            if(num_animals_space > 0){
                for(int d = 0; d < num_spaces; d++){
                    cout << " ";
                    if((d + num_animals_space) == 7){
                        break;
                    }
                }
            }else
                cout << "       ";

        }
        cout << "*";
        cout << endl;
        //LINHA DOS ANIMAIS

        //LINHA DOS ALIMENTOS
        for(int b = 0; b < r->getNC(); b++) {
            cout << "*";
            int num_alimentos_space = 0;
            int num_spaces = 7;
            for(int c = 0; c < r->getAlimentoVector().size(); c++){
                if(r->getAlimentoVector()[c]->getY() == (a + 1) && r->getAlimentoVector()[c]->getX() == (b + 1)){
                    cout << r->getAlimentoVector()[c]->getAbreviation();
                    ++num_alimentos_space;
                    --num_spaces;
                }
            }

            if(num_alimentos_space > 0){
                for(int d = 0; d < num_spaces; d++){
                    cout << " ";
                    if((d + num_alimentos_space) == 7){
                        break;
                    }
                }
            }else
                cout << "       ";

        }
        cout << "*";
        cout << endl;
        //LINHA DOS ALIMENTOS

        for(int b = 0; b < r->getNC(); b++) {
            cout << "*       ";
        }
        cout << "*";
    }
    cout << endl;
    for(int b = 0; b < r->getNC(); b++) {
        for (int i = 0; i < 8; i++) {
            cout << "*";
        }
    }
    cout << "*";
}

void Interface::run(){
    srand (time(NULL));

    cout << " ----------> BEM VINDO A RESERVA NATURAL!!!! <----------" << endl << endl;

    string answer;
    string filename;
    int nl, nc;

    loadCommandsFromFile("constantes.txt");

    //OBTENCAO DE NC E NL
    do{

        cout << "Insira um Numero de Linhas: (NL)" << endl;
        cin >> nl;
        cin.clear();
        cin.ignore(nl, '\n');

        if(nl < 16 || nl > 500) {
            cout << "[ERRO] Numero de linhas entre 16 e 500" << endl;
            continue;
        }

        cout << endl << "Insira um Numero de Colunas: (NC)" << endl;
        cin >> nc;
        cin.clear();
        cin.ignore(nc, '\n');

        if(nc < 16 || nc > 500) {
            cout << "[ERRO] Numero de colunas entre 16 e 500" << endl;
            continue;
        }


    }while((nl < 16 || nc < 16) || (nl > 500 || nc > 500));

    r->setNL(nl);
    r->setNC(nc);
    //OBTENCAO DE NC E NL

    while(1){

        cout << "[COMANDOS] Insira os comandos que pretende executar? " << endl;
        getline(cin, answer);

        loadCommandsFromKeyboard(answer);

        //BOARD
        board();
        cout << endl;
        //BOARD

        interfaceStatus = getInterfaceAsString();
        cout << interfaceStatus << endl;

        cout << endl << endl;
    }

}

string Interface::getInterfaceAsString() const{
    ostringstream oss;

    oss << endl << endl << " -------------------------------" << endl
        << "| DETALHES ATUAIS DO TABULEIRO: |" << endl
        << " -------------------------------" << endl << endl
        << "Animais: " << endl << r->getAnimalVectorAsString() << endl
        << "Alimento: " << endl << r->getAlimentosVectorAsString() << endl
        << "Numero animais: "  << r->getAnimalVector().size() << endl
        << "Quantidade de Comida Disponivel: " << r->getAlimentoVector().size() << endl;


    return oss.str();
}






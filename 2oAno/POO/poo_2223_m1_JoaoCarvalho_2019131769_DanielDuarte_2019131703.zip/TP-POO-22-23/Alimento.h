//
// Created by João Carvalho on 07/11/2022.
//

#ifndef TP_POO_22_23_ALIMENTO_H
#define TP_POO_22_23_ALIMENTO_H

#include <iostream>
#include <sstream>
#include <string.h>
#include <sstream>

using namespace std;

class Alimento{
public:
    Alimento(char& abreviation/*, int id*/, int y, int x);
    ~Alimento();

    char getAbreviation() const;
    int getID() const;
    int  getlifeTime() const;
    int getNutValue() const;
    int getToxicity() const;
    string getSmell() const;
    int getY() const;
    int getX() const;

    string getAlimentosAsString() const;

    void setID(int number);


private:
    char abreviation;
    int id;
    int lifeTime;
    int nutValue;
    int toxicity;
    string smell;

    int y;
    int x;
};

#endif //TP_POO_22_23_ALIMENTO_H

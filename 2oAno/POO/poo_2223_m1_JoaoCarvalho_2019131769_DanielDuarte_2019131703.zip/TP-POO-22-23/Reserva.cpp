//
// Created by João Carvalho on 21/11/2022.
//

#include "Reserva.h"

int Reserva::cnt = 0;

Reserva::~Reserva() {
    for(auto it = animais.begin(); it < animais.end(); it++)
        delete (*it);

    for(auto it = alimentos.begin(); it < alimentos.end(); it++)
        delete (*it);
}

void Reserva::setNL(int nl) {
    NL = nl;
}

void Reserva::setNC(int nc) {
    NC = nc;
}

int Reserva::getNL() const {
    return NL;
}

int Reserva::getNC() const {
    return NC;
}

vector<Animal*> Reserva::getAnimalVector(){
    return animais;
}

vector<Alimento*> Reserva::getAlimentoVector(){
    return alimentos;
}

void Reserva::criaAnimal(const char &abrv, int y, int x) {
    animais.push_back(new Animal((char&) abrv, y, x));
    int size = animais.size();
    animais[size - 1]->setID(cnt++);
    animais[size - 1]->setInitialHealth(abrv);
    animais[size - 1]->setLTime(abrv);
}

void Reserva::criaAlimento(const char &abrv, int y, int x) {
    alimentos.push_back(new Alimento((char&) abrv, y, x));
    int size = alimentos.size();
    alimentos[size - 1]->setID(cnt++);
}

string Reserva::getAnimalVectorAsString() {

    ostringstream oss;

    for(int i = 0; i < animais.size(); i++){
        oss << "Animal " << animais[i]->getID() << endl
            << animais[i]->getAnimalAsString() << endl;
    }

    return oss.str();
}

string Reserva::getAlimentosVectorAsString() {

    ostringstream oss;

    for(int i = 0; i < alimentos.size(); i++){
        oss << "Alimento " << alimentos[i]->getID() << endl
            << alimentos[i]->getAlimentosAsString() << endl;
    }

    return oss.str();
}
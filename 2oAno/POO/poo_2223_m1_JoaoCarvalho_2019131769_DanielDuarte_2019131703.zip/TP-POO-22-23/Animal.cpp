//
// Created by João Carvalho on 07/11/2022.
//

#include "Animal.h"

string Animal::NCoelho = "a";
int Animal::SCoelho = 0;
int Animal::VCoelho = 0;
string Animal::NOvelha = "a";
int Animal::SOvelha  = 0;
int Animal::VOvelha = 0;
string Animal::NLobo = "a";
int Animal::SLobo = 0;
int Animal::VLobo = 0;
string Animal::NCanguru = "a";
int Animal::SCanguru = 0;
int Animal::VCanguru = 0;
string Animal::NMisterio = "a";
int Animal::SMisterio = 0;
int Animal::VMisterio = 0;

Animal::Animal(char& abrv, int y, int x): abreviation(abrv), y(y), x(x){}

Animal::~Animal() {
}

string Animal::getAnimalAsString() const {
    ostringstream oss;

    oss << "\tAnimal: " << abreviation << endl
        << "\tId: " << id << endl
        << "\tPosicao: " << y << " " << x << endl
        << "\tVida Inicial: " << initialHealth << endl //MUDAR PARA SER DINAMICO RELATIVAMENTE AO ANIMAL QUE APARECE
        << "\tTempo de Vida: " << lifeTime << endl; //MUDAR PARA SER DINAMICO RELATIVAMENTE AO ANIMAL QUE APARECE

    return oss.str();
}

int Animal::getID() const {
    return id;
}

void Animal::setID(int number){
    id = number;
    //cout << "IDDDDD " << id << endl;
}

char Animal::getAbreviation() const {
    return abreviation;
}

int Animal::getX() const {
    return x;
}

int Animal::getY() const {
    return y;
}

void Animal::setX(int number){
    x = number;
}

void Animal::setY(int number){
    y = number;
}

void Animal::setLife(string animalType, int health) {

    if(animalType == "SCoelho")
        SCoelho = health;

    if(animalType == "SOvelha")
        SOvelha = health;

    if(animalType == "SLobo")
        SLobo = health;

    if(animalType == "SCanguru")
        SCanguru = health;

    if(animalType == "SMisterio")
        SMisterio = health;
}

void Animal::setLifeTime(string animalType, int moments) {

    if(animalType == "VCoelho")
        VCoelho = moments;

    if(animalType == "VOvelha")
        VOvelha = moments;

    if(animalType == "VLobo")
        VLobo = moments;

    if(animalType == "VCanguru")
        VCanguru = moments;

    if(animalType == "VMisterio")
        VMisterio = moments;
}

void Animal::setAbreviation(string animalType, string character) {
    if(animalType == "NCoelho")
        NCoelho = character;

    if(animalType == "NOvelha")
        NOvelha = character;

    if(animalType == "NLobo")
        NLobo = character;

    if(animalType == "NCanguru")
        NCanguru = character;

    if(animalType == "NMisterio")
        NMisterio = character;
}

void Animal::setInitialHealth(char abrv) {

    if(abrv == 'c'){
        initialHealth = SCoelho;
    }

    if(abrv == 'o'){
        initialHealth = SOvelha;
    }

    if(abrv == 'l'){
        initialHealth = SLobo;
    }

    if(abrv == 'g'){
        initialHealth = SCanguru;
    }

    if(abrv == 'm'){
        initialHealth = SMisterio;
    }

}

void Animal::setLTime(char abrv) {
    if(abrv == 'c'){
        lifeTime = VCoelho;
    }

    if(abrv == 'o'){
        lifeTime = VOvelha;
    }

    if(abrv == 'l'){
        lifeTime = VLobo;
    }

    if(abrv == 'g'){
        lifeTime = VCanguru;
    }

    if(abrv == 'm'){
        lifeTime = VMisterio;
    }
}

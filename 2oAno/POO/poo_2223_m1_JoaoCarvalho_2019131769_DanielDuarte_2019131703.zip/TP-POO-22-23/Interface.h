//
// Created by João Carvalho on 07/11/2022.
//

#ifndef TP_POO_22_23_INTERFACE_H
#define TP_POO_22_23_INTERFACE_H

#include <iostream>
#include <sstream>
#include <string.h>
#include <vector>

using namespace std;

class Reserva;

class Interface{
public:
    Interface(Reserva *r):r(r){};
    ~Interface();

    void board();
    void run();

    string getInterfaceAsString() const;
    void readConstantes(vector<string> sepCommands);
    void loadCommandsFromKeyboard(string line);
    void loadCommandsFromFile(const string& filename);
    void commandAnimal(vector<string> sepCommands);
    void commandKill(vector<string> sepCommands);
    void commandFood(vector<string> sepCommands);
    void commandFeed(vector<string> sepCommands);
    void commandFeedID(vector<string> sepCommands);
    void commandNoFood(vector<string> sepCommands);
    void commandEmpty(vector<string> sepCommands);
    void commandSee(vector<string> sepCommands);
    void commandInfo(vector<string> sepCommands);
    void commandNext(vector<string> sepCommands);
    void commandAnim(vector<string> sepCommands);
    void commandVisAnim(vector<string> sepCommands);
    void commandStore(vector<string> sepCommands);
    void commandReStore(vector<string> sepCommands);
    void commandLoad(vector<string> sepCommands);
    void commandSlide(vector<string> sepCommands);
    void commandExit(vector<string> sepCommands);
    //PROJECT_NAME
    bool isNumber(const string& str);
    vector<string> divideString(string str) const;

private:
    string interfaceStatus;
    Reserva* r;
    vector<string> commandsV;
};

#endif //TP_POO_22_23_INTERFACE_H
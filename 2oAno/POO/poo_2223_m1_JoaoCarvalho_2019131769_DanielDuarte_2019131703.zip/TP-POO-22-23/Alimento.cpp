//
// Created by João Carvalho on 07/11/2022.
//

#include "Alimento.h"

Alimento::Alimento(char& abrv, int y, int x):abreviation(abrv), y(y), x(x){
    //cout << "Alimento criado com sucesso" << endl;
}

Alimento::~Alimento() {

}

void Alimento::setID(int number){
    id = number;
}

int Alimento::getID() const {
    return id;
}

char Alimento::getAbreviation() const {
    return abreviation;
}

int Alimento::getlifeTime() const {
    return lifeTime;
}

int Alimento::getNutValue() const {
    return nutValue;
}

int Alimento::getToxicity() const {
    return toxicity;
}

string Alimento::getSmell() const {
    return smell;
}

string Alimento::getAlimentosAsString() const {
    ostringstream oss;

    oss << "\tAlimento: " << abreviation << endl
        << "\tId: " << id << endl
        << "\tPosicao: " << y << " " << x << endl;

    return oss.str();
}

int Alimento::getY() const {
    return y;
}

int Alimento::getX() const {
    return x;
}


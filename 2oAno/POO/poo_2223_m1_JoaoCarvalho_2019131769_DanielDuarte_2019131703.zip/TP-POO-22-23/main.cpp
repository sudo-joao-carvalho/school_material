//
// Created by João Carvalho on 07/11/2022.
//

#include <iostream>
#include "Reserva.h"
#include "Interface.h"

int main() {

    Interface p(new Reserva());
    p.run();

    return 0;
}
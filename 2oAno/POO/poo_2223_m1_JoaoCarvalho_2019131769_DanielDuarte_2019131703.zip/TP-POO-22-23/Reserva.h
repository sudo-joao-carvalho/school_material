//
// Created by João Carvalho on 21/11/2022.
//

#ifndef TP_POO_22_23_RESERVA_H
#define TP_POO_22_23_RESERVA_H

#include <iostream>
#include <sstream>
#include <string.h>
#include <vector>
#include "Animal.h"
#include "Alimento.h"

class Reserva{
public:
    Reserva(){};
    ~Reserva();

    void setNL(int nl);
    void setNC(int nc);

    int getNL() const;
    int getNC() const;

    //void criaAnimal(const char& abrv, int id);
    void criaAnimal(const char& abrv/*, int id*/, int y, int x);
    void criaAlimento(const char& abrv/*, int id*/, int y, int x);
    vector<Animal*> getAnimalVector();
    string getAnimalVectorAsString();
    vector<Alimento*> getAlimentoVector();
    string getAlimentosVectorAsString();

private:
    static int cnt;

    int NL;
    int NC;

    vector<Animal*> animais;
    vector<Alimento*> alimentos;
};

#endif //TP_POO_22_23_RESERVA_H

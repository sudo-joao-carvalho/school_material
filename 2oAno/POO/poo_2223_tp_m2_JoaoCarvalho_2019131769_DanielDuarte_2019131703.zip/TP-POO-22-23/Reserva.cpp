//
// Created by João Carvalho on 21/11/2022.
//

#include "Reserva.h"

int Reserva::cnt = 0;

Reserva::Reserva(const Reserva& orig){
    *this = orig;
}

Reserva::~Reserva() {
    for(auto it = animais.begin(); it < animais.end(); it++)
        delete (*it);

    for(auto it = alimentos.begin(); it < alimentos.end(); it++)
        delete (*it);
}

/*Reserva& Reserva::operator=(const Reserva& orig){

    if(this == &orig){
        return *this;
    }

    for(int i = 0; i < animais.size(); i++){
        delete animais[i];
    }

    for(int i = 0; i < alimentos.size(); i++){
        delete alimentos[i];
    }

    animais.clear();
    alimentos.clear();

    for(int i = 0; i < orig.animais.size(); i++){
        Animal* a = orig.animais[i];
        animais.emplace_back(a);
    }

    for(int i = 0; i < orig.alimentos.size(); i++){
        Alimento* a = orig.alimentos[i];
        alimentos.emplace_back(a);
    }

    return *this;

}*/

void Reserva::setNL(int nl) {
    NL = nl;
}

void Reserva::setNC(int nc) {
    NC = nc;
}

int Reserva::getNL() const {
    return NL;
}

int Reserva::getNC() const {
    return NC;
}

vector<Animal*> Reserva::getAnimalVector() const{
    return animais;
}

vector<Alimento*> Reserva::getAlimentoVector() const{
    return alimentos;
}

void Reserva::criaAnimal(const char &abrv, int y, int x) { //c o l g m
    if(abrv == 'c'){
        animais.push_back(new Coelho((char&) abrv, cnt++, y, x));
    }

    if(abrv == 'o'){
        animais.push_back(new Ovelha((char&) abrv, cnt++, y, x));
    }

    if(abrv == 'l'){
        animais.push_back(new Lobo((char&) abrv, cnt++, y, x));
    }

    if(abrv == 'g'){
        animais.push_back(new Canguru((char&) abrv, cnt++, y, x));
    }

    if(abrv == 'm'){
        animais.push_back(new AnimalM((char&) abrv, cnt++, y, x));
    }
}

void Reserva::criaAlimento(const char &abrv, int y, int x) { //r t p b a

    if(abrv == 'r'){
        alimentos.push_back(new Relva((char&) abrv, cnt++, y, x));
    }

    if(abrv == 't'){
        alimentos.push_back(new Cenoura((char&) abrv, cnt++, y, x));
    }

    if(abrv == 'p'){
        alimentos.push_back(new Corpo((char&) abrv, cnt++, y, x));
    }

    if(abrv == 'b'){
        alimentos.push_back(new Bife((char&) abrv, cnt++, y, x));
    }

    if(abrv == 'a'){
        alimentos.push_back(new AlimentoM((char&) abrv, cnt++, y, x));
    }
}

string Reserva::getAnimalVectorAsString() const{

    ostringstream oss;

    for(int i = 0; i < animais.size(); i++){
        oss << "Animal " << animais[i]->getID() << endl
            << animais[i]->getAnimalAsString() << endl;
    }

    return oss.str();
}

string Reserva::getAlimentosVectorAsString() const{

    ostringstream oss;

    for(int i = 0; i < alimentos.size(); i++){
        oss << "Alimento " << alimentos[i]->getID() << endl
            << alimentos[i]->getAlimentosAsString() << endl;
    }

    return oss.str();
}

void Reserva::killAnimalByPosition(int l, int c){ //c o l g m

    for (auto it = animais.begin(); it != animais.end();) {
        if ((*it)->getY() == l && (*it)->getX() == c) {
            delete *it;
            animais.erase(it);
            cout << "Animais na posicao " << c << " " << l << " morto" << endl;
            return;
        }else{
            it++;
        }

    }

}

void Reserva::killAnimalByID(int id) {

    for(auto it = animais.begin(); it != animais.end(); it++){
        if((*it)->getID() == id){
            delete *it;
            animais.erase(it);
            cout << "Animal com id " << id << " morto" << endl;
            return;
        }else{
            it++;
        }

    }

}

void Reserva::killFoodByPosition(int l, int c){ //r t p b a
    for (auto it = alimentos.begin(); it != alimentos.end();) {
        if ((*it)->getY() == l && (*it)->getX() == c) {
                delete *it;
                alimentos.erase(it);
                cout << "Alimentos na posicao " << c << " " << l << " removidos" << endl;
                return;
        }else
            it++;
    }
}

void Reserva::killFoodByID(int id){
    for (auto it = alimentos.begin(); it != alimentos.end();) {
        if ((*it)->getID() == id) {
            delete *it;
            alimentos.erase(it);
            cout << "Alimento com id " << id << " removido" << endl;
            return;
        }else
            it++;
    }
}

void Reserva::feedAnimalByPosition(int l, int c, int nutritionPoints, int toxicityPoints) {

    for(auto a: animais){
        if(a->getY() == l && a->getX() == c){
            a->setHealth(a->getHealth() + nutritionPoints - toxicityPoints);
            return;
        }
    }
}

void Reserva::feedAnimalById(int id, int nutritionPoints, int toxicityPoints){

    for(auto a: animais){
        if(a->getID() == id){
            a->setHealth(a->getHealth() + nutritionPoints - toxicityPoints);
            return;
        }
    }

}

int Reserva::getSeconds() const{
    return seconds;
}

void Reserva::setSeconds(int sec) {
    seconds = sec;
}
//
// CrsetHealthed by João Carvalho on 07/11/2022.
//

#ifndef TP_POO_22_23_ANIMAL_H
#define TP_POO_22_23_ANIMAL_H

#include <iostream>
#include <sstream>
#include <string>
#include <cstdlib>
#include <sstream>

using namespace std;

class Animal{
public:
    Animal(char& abreviation, int id, int y, int x);
    Animal(const Animal& animal);

    virtual ~Animal();

    char getAbreviation() const;
    int getID() const;
    string getAnimalAsString() const;
    int getX() const;
    int getY() const;
    virtual int getHealth() const;

    void setID(int number);
    void setX(int number);
    void setY(int number);
    virtual void setHealth(int number);

protected:

    char abreviation;
    int id;
    int health;
    int lifeTime;

    int y;
    int x;


};

/*
 * Coelho
 * Ovelha
 * Lobo
 * Canguru
 * AnimalM*/

class Coelho: public Animal{
public:
    Coelho(char& abreviation, int id, int y, int x);
    ~Coelho() override;

    void setHealth(int number) override;

    int getHealth() const override;
private:
    int starvingPoints;
    int minWeight;
    int maxWeight;
    int weight;

};

class Ovelha: public Animal{
public:
    Ovelha(char& abreviation, int id, int y, int x);
    ~Ovelha() override;

    void setHealth(int number) override;

    int getHealth() const override;
private:
    int starvingPoints;
    int minWeight;
    int maxWeight;
    int weight;
};

class Lobo: public Animal{
public:
    Lobo(char& abreviation, int id, int y, int x);
    ~Lobo() override;

    void setHealth(int number) override;

    int getHealth() const override;
private:
    int starvingPoints;
    int weight;
};

class Canguru: public Animal{
public:
    Canguru(char& abreviation, int id, int y, int x);
    ~Canguru() override;

    void setHealth(int number) override;

    int getHealth() const override;
private:
    int starvingPoints;
    int weight;
};

class AnimalM: public Animal{
public:
    AnimalM(char& abreviation, int id, int y, int x);
    ~AnimalM() override;

    void setHealth(int number) override;

    int getHealth() const override;
private:
    int starvingPoints;
    int minWeight;
    int maxWeight;
    int weight;
};

#endif //TP_POO_22_23_ANIMAL_H

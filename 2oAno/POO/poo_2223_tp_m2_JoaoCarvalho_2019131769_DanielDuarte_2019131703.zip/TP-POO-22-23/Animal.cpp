//
// Created by João Carvalho on 07/11/2022.
//

#include "Animal.h"
#include "Simulador.h"

Animal::Animal(char& abrv, int id, int y, int x): id(id), y(y), x(x){
    abreviation = Simulador::getN(abrv);
    health = Simulador::getS(abrv);
    lifeTime = Simulador::getV(abrv);
}

Animal::Animal(const Animal& animal){

    abreviation = animal.abreviation;
    id = animal.id;
    y = animal.y;
    x = animal.x;
    health = animal.health;
    lifeTime = animal.lifeTime;

}

Animal::~Animal() {
}

string Animal::getAnimalAsString() const {
    ostringstream oss;

    oss << "\tAnimal: " << abreviation << endl
        << "\tId: " << id << endl
        << "\tPosicao: " << y << " " << x << endl
        << "\tVida: " << health << endl //MUDAR PARA SER DINAMICO RELATIVAMENTE AO ANIMAL QUE APARECE
        << "\tTempo de Vida: " << lifeTime << endl; //MUDAR PARA SER DINAMICO RELATIVAMENTE AO ANIMAL QUE APARECE

    return oss.str();
}

int Animal::getID() const {
    return id;
}

void Animal::setID(int number){
    id = number;
}

char Animal::getAbreviation() const {
    return abreviation;
}

int Animal::getX() const {
    return x;
}

int Animal::getY() const {
    return y;
}

int Animal::getHealth() const {
    return health;
}

void Animal::setX(int number){
    x = number;
}

void Animal::setY(int number){
    y = number;
}

void Animal::setHealth(int number) {
    health = number;
}

Coelho::Coelho(char& abrv, int id, int y, int x): Animal(abrv, id, y, x){
    abreviation = Simulador::getN(abrv);
    health = Simulador::getS(abrv);
    lifeTime = Simulador::getV(abrv);

    minWeight = 1;
    maxWeight = 4;
    weight = rand() % (maxWeight - minWeight + 1) + minWeight;
}

Coelho::~Coelho(){
    cout << "Coelho Destruido" << endl;
}

void Coelho::setHealth(int number) {
    health = number;
}

int Coelho::getHealth() const {
    return health;
}

Ovelha::Ovelha(char& abrv, int id, int y, int x): Animal(abrv, id, y, x){
    abreviation = Simulador::getN(abrv);
    health = Simulador::getS(abrv);
    lifeTime = Simulador::getV(abrv);

    minWeight = 4;
    maxWeight = 8;
    weight = rand() % (maxWeight - minWeight + 1) + minWeight;
}

Ovelha::~Ovelha() {
    cout << "Ovelha Destruida" << endl;
}

void Ovelha::setHealth(int number) {
    health = number;
}

int Ovelha::getHealth() const {
    return health;
}

Lobo::Lobo(char& abrv, int id, int y, int x): Animal(abrv, id, y, x){
    abreviation = Simulador::getN(abrv);
    health = Simulador::getS(abrv);
    lifeTime = Simulador::getV(abrv);

    weight = 15;
}

Lobo::~Lobo() {
    cout << "Lobo Destruido" << endl;
}

void Lobo::setHealth(int number) {
    health = number;
}

int Lobo::getHealth() const {
    return health;
}

Canguru::Canguru(char& abrv, int id, int y, int x): Animal(abrv, id, y, x){
    abreviation = Simulador::getN(abrv);
    health = Simulador::getS(abrv);
    lifeTime = Simulador::getV(abrv);

    weight = 10;
}

Canguru::~Canguru() {
    cout << "Canguru Destruido" << endl;
}

void Canguru::setHealth(int number) {
    health = number;
}

int Canguru::getHealth() const {
    return health;
}

AnimalM::AnimalM(char& abrv, int id, int y, int x): Animal(abrv, id, y, x){

    //pterodactilo
    //voa 1 casa e para apos nascer
    //passa a adulto apos 30 instantes
    //voa 5 casas e faz uma pausa nesta quando adulto
    //peso quando nasce entre 1 e 15
    //peso depois de adulto entre 15 e 100

    abreviation = Simulador::getN(abrv);
    health = Simulador::getS(abrv);
    lifeTime = Simulador::getV(abrv);

    minWeight = 1;
    maxWeight = 15;
    weight = rand() % (maxWeight - minWeight + 1) + minWeight;
}

AnimalM::~AnimalM() {
    cout << "AnimalM Destruido" << endl;
}

void AnimalM::setHealth(int number) {
    health = number;
}

int AnimalM::getHealth() const {
    return health;
}

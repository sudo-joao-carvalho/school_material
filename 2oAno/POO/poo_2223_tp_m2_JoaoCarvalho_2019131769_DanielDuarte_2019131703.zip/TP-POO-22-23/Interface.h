//
// Created by João Carvalho on 07/11/2022.
//

#ifndef TP_POO_22_23_INTERFACE_H
#define TP_POO_22_23_INTERFACE_H

#include <map>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include "Terminal.h"

using namespace std;
using namespace term;

class Alimento;
class Animal;
class Reserva;
class Simulador;

class Interface{
public:
    //Construtores e Destrutores
    Interface(Simulador* sim, Terminal& t) /*= default*/;
    ~Interface(){};

    //Run
    void board();
    void run();
    string getInterfaceAsString() const;

    //aux function
    vector<string> divideString(string str) const;

    //command phase
    string readCommandsFromKeyboard(string line);
    void commandAnimal(char animalType, int l, int c);
    void commandKill(int l, int c);
    void commandKillId(int id);
    void commandFood(char foodType, int l, int c);
    void commandFeed(int l, int c, int nutritionPoints, int toxicityPoints);
    void commandFeedID(int id, int nutritionPoints, int toxicityPoints);
    void commandNoFood(int l, int c, int id);
    void commandEmpty(int l, int c);
    void commandSee(int l, int c);
    void commandInfo(int id);
    void commandNext();
    void commandNextN(int n);
    void commandNextNP(int n, int p);
    void commandAnim();
    void commandVisAnim();
    void commandStore(string name);
    void commandReStore(string name);
    void commandLoad(const string& nome_fich);
    void commandSlide(const string& direction);

    void sleepChrono(int pauseTime);

private:
    string interfaceStatus;
    Simulador* simulator;
    vector<string> commandsV;

    static int _right;
    static int _down;

    //Terminal vars
    Terminal &t;
    Window commands;
    Window reserva;
    Window stateReserva;
    Window printMessages;
    Window commandsResult;
};

#endif //TP_POO_22_23_INTERFACE_H
//
// Created by João Carvalho on 07/11/2022.
//

#include "Terminal.h"
#include "Interface.h"
#include "Reserva.h"
#include "Simulador.h"
#include <fstream>
#include <ncurses.h>
#include <thread>
#include <chrono>

int Interface::_right = 0;
int Interface::_down = 0;

Interface::Interface(Simulador* sim, Terminal& t): simulator(sim), t(t), reserva(2,2,90,44), stateReserva(93,2,45,44), commands(2,46,183,5), printMessages(2,51,183,5),
                                                   commandsResult(140,2,45,44){}

vector<string> Interface::divideString(string str) const{
    string aux;

    stringstream ss(str);
    vector<string> palavras;

    while (ss >> aux){
        palavras.push_back(aux);
    }

    return palavras;
}

void Interface::commandNext(){

    int secs = simulator->getReserva()->getSeconds() + 1;
    simulator->getReserva()->setSeconds(secs);
    commandsResult << "Segundos: " << simulator->getReserva()->getSeconds();

    commandsResult.clear();

}

void Interface::commandNextN(int n){

    int secs = simulator->getReserva()->getSeconds() + n;
    simulator->getReserva()->setSeconds(secs);
    commandsResult << "Segundos: " << simulator->getReserva()->getSeconds();

    commandsResult.clear();

}

void Interface::commandNextNP(int n, int p) {

    for(int i = 0; i < n; i++){
        int secs = simulator->getReserva()->getSeconds() + 1;
        simulator->getReserva()->setSeconds(secs);
        commandsResult << "Segundos: " << simulator->getReserva()->getSeconds();

        sleepChrono(p);
        commandsResult.clear();
    }

}

void Interface::sleepChrono(int pauseTime) {
    this_thread::sleep_for(chrono::seconds(pauseTime));
}

void Interface::commandSlide(const string& direction){

    if(direction == "up"){
        _down -= 10;
        if(_down <= 0){
            printMessages << "[AVISO] Atingiu o limite superior da reserva";
            printMessages.clear();
            _down = 0;
        }
    }

    if(direction == "down"){
        _down += 10;
        if(_down >= simulator->getReserva()->getNL()){
            printMessages << "[AVISO] Atingiu o limite inferior da reserva";
            printMessages.clear();
            _down -= 10;
        }
    }

    if(direction == "left"){
        _right -= 10;
        if(_right <= 0){
            printMessages << "[AVISO] Atingiu o limite esquerdo da reserva";
            printMessages.clear();
            _right = 0;
        }
    }

    if(direction == "right"){
        _right += 10;
        if(_right >= simulator->getReserva()->getNC()){
            printMessages << "[AVISO] Atingiu o limite direito da reserva";
            printMessages.clear();
            _right -= 10;
        }
    }

}

void Interface::commandAnimal(char animalType, int l, int c) {

    if(l == 0 && c == 0){
        if(animalType == 'c'){ //c o l g m
            //PASSAR COORDENADAS RANDOM QUANDO N SAO DADAS PELO USER
            int y = 0;
            int x = 0;
            y = rand() % simulator->getReserva()->getNL() + 1;
            x = rand() % simulator->getReserva()->getNC() + 1;
            simulator->getReserva()->criaAnimal(animalType, y, x);
            //PASSAR COORDENADAS RANDOM QUANDO N SAO DADAS PELO USER

            return ;
        }

        if(animalType == 'o'){
            //PASSAR COORDENADAS RANDOM QUANDO N SAO DADAS PELO USER
            int y = 0;
            int x = 0;
            y = rand() % simulator->getReserva()->getNL() + 1;
            x = rand() % simulator->getReserva()->getNC() + 1;
            simulator->getReserva()->criaAnimal(animalType, y, x);
            //PASSAR COORDENADAS RANDOM QUANDO N SAO DADAS PELO USER

            return ;
        }else if(animalType == 'l'){
            //PASSAR COORDENADAS RANDOM QUANDO N SAO DADAS PELO USER
            int y = 0;
            int x = 0;
            y = rand() % simulator->getReserva()->getNL() + 1;
            x = rand() % simulator->getReserva()->getNC() + 1;
            simulator->getReserva()->criaAnimal(animalType, y, x);
            //PASSAR COORDENADAS RANDOM QUANDO N SAO DADAS PELO USER

            return ;
        }else if(animalType == 'g'){
            //PASSAR COORDENADAS RANDOM QUANDO N SAO DADAS PELO USER
            int y = 0;
            int x = 0;
            y = rand() % simulator->getReserva()->getNL() + 1;
            x = rand() % simulator->getReserva()->getNC() + 1;
            simulator->getReserva()->criaAnimal(animalType, y, x);
            //PASSAR COORDENADAS RANDOM QUANDO N SAO DADAS PELO USER

            return ;
        }else if(animalType == 'm'){
            //PASSAR COORDENADAS RANDOM QUANDO N SAO DADAS PELO USER
            int y = 0;
            int x = 0;
            y = rand() % simulator->getReserva()->getNL() + 1;
            x = rand() % simulator->getReserva()->getNC() + 1;
            simulator->getReserva()->criaAnimal(animalType, y, x);
            //PASSAR COORDENADAS RANDOM QUANDO N SAO DADAS PELO USER

            return ;
        }else {
            printMessages << "[ERRO] Tipo de animal errado";
            printMessages.clear();
        }
    }else{
        if(animalType == 'c'){ //c o l g m
            simulator->getReserva()->criaAnimal(animalType, l, c);
            return ;
        }else if(animalType == 'o'){
            simulator->getReserva()->criaAnimal(animalType, l, c);
            return ;
        }else if(animalType == 'l'){
            simulator->getReserva()->criaAnimal(animalType, l, c);
            return;
        }else if(animalType == 'g'){
            simulator->getReserva()->criaAnimal(animalType, l, c);
            return ;
        }else if(animalType == 'm'){
            simulator->getReserva()->criaAnimal(animalType, l, c);
            return ;
        }else{
            printMessages << "[ERRO] Tipo de animal errado";
            printMessages.clear();
        }
    }
}

void Interface::commandKill(int l, int c) {
    simulator->getReserva()->killAnimalByPosition(l, c);
}

void Interface::commandKillId(int id) {
    simulator->getReserva()->killAnimalByID(id);
}

void Interface::commandFood(char foodType, int l, int c) {

    if(l == 0 && c == 0){
        if(foodType == 'r'){//r t p b a
            //PASSAR COORDENADAS RANDOM QUANDO N SAO DADAS PELO USER
            int y = 0;
            int x = 0;
            y = rand() % simulator->getReserva()->getNL() + 1;
            x = rand() % simulator->getReserva()->getNC() + 1;

            //VERIFICAR SE JA EXISTE ALGUM ALIMENTO NAQUELA ZONA
            if(!simulator->getReserva()->getAlimentoVector().empty()){
                for(int i = 0; i < simulator->getReserva()->getAlimentoVector().size(); i++) {
                    if (simulator->getReserva()->getAlimentoVector()[i]->getY() == y && simulator->getReserva()->getAlimentoVector()[i]->getX() == x) {
                        printMessages << "Ja existe um alimento neste sitio";
                        printMessages.clear();
                        return;
                    }else {
                        simulator->getReserva()->criaAlimento(foodType, y, x);
                        return;
                    }
                }
            }else {
                simulator->getReserva()->criaAlimento(foodType, y, x);
                return;
            }
            //PASSAR COORDENADAS RANDOM QUANDO N SAO DADAS PELO USER

            return ;
        }

        if(foodType == 't'){//r t b a
            //PASSAR COORDENADAS RANDOM QUANDO N SAO DADAS PELO USER
            int y = 0;
            int x = 0;
            y = rand() % simulator->getReserva()->getNL() + 1;
            x = rand() % simulator->getReserva()->getNC() + 1;

            //VERIFICAR SE JA EXISTE ALGUM ALIMENTO NAQUELA ZONA
            if(!simulator->getReserva()->getAlimentoVector().empty()){
                for(int i = 0; i < simulator->getReserva()->getAlimentoVector().size(); i++) {
                    if (simulator->getReserva()->getAlimentoVector()[i]->getY() == y && simulator->getReserva()->getAlimentoVector()[i]->getX() == x) {
                        printMessages << "Ja existe um alimento neste sitio";
                        printMessages.clear();
                        return;
                    }else {
                        simulator->getReserva()->criaAlimento(foodType, y, x);
                        return;
                    }
                }
            }else {
                simulator->getReserva()->criaAlimento(foodType, y, x);
                return;
            }
            //PASSAR COORDENADAS RANDOM QUANDO N SAO DADAS PELO USER

            return ;
        }

        if(foodType == 'p'){//r t p b a
            //PASSAR COORDENADAS RANDOM QUANDO N SAO DADAS PELO USER
            int y = 0;
            int x = 0;
            y = rand() % simulator->getReserva()->getNL() + 1;
            x = rand() % simulator->getReserva()->getNC() + 1;

            //VERIFICAR SE JA EXISTE ALGUM ALIMENTO NAQUELA ZONA
            if(!simulator->getReserva()->getAlimentoVector().empty()){
                for(int i = 0; i < simulator->getReserva()->getAlimentoVector().size(); i++) {
                    if (simulator->getReserva()->getAlimentoVector()[i]->getY() == y && simulator->getReserva()->getAlimentoVector()[i]->getX() == x) {
                        printMessages << "Ja existe um alimento neste sitio";
                        printMessages.clear();
                        return;
                    }else {
                        simulator->getReserva()->criaAlimento(foodType, y, x);
                        return;
                    }
                }
            }else {
                simulator->getReserva()->criaAlimento(foodType, y, x);
                return;
            }
            //PASSAR COORDENADAS RANDOM QUANDO N SAO DADAS PELO USER

            return ;
        }

        if(foodType == 'b'){//r t b a
            //PASSAR COORDENADAS RANDOM QUANDO N SAO DADAS PELO USER
            int y = 0;
            int x = 0;
            y = rand() % simulator->getReserva()->getNL() + 1;
            x = rand() % simulator->getReserva()->getNC() + 1;

            //VERIFICAR SE JA EXISTE ALGUM ALIMENTO NAQUELA ZONA
            if(!simulator->getReserva()->getAlimentoVector().empty()){
                for(int i = 0; i < simulator->getReserva()->getAlimentoVector().size(); i++) {
                    if (simulator->getReserva()->getAlimentoVector()[i]->getY() == y && simulator->getReserva()->getAlimentoVector()[i]->getX() == x) {
                        printMessages << "Ja existe um alimento neste sitio";
                        printMessages.clear();
                        return;
                    }else {
                        simulator->getReserva()->criaAlimento(foodType, y, x);
                        return;
                    }
                }
            }else {
                simulator->getReserva()->criaAlimento(foodType, y, x);
                return;
            }
            //PASSAR COORDENADAS RANDOM QUANDO N SAO DADAS PELO USER

            return ;
        }

        if(foodType == 'a'){//r t b a
            //PASSAR COORDENADAS RANDOM QUANDO N SAO DADAS PELO USER
            int y = 0;
            int x = 0;
            y = rand() % simulator->getReserva()->getNL() + 1;
            x = rand() % simulator->getReserva()->getNC() + 1;

            //VERIFICAR SE JA EXISTE ALGUM ALIMENTO NAQUELA ZONA
            if(!simulator->getReserva()->getAlimentoVector().empty()){
                for(int i = 0; i < simulator->getReserva()->getAlimentoVector().size(); i++) {
                    if (simulator->getReserva()->getAlimentoVector()[i]->getY() == y && simulator->getReserva()->getAlimentoVector()[i]->getX() == x) {
                        printMessages << "Ja existe um alimento neste sitio";
                        printMessages.clear();
                        return;
                    }else {
                        simulator->getReserva()->criaAlimento(foodType, y, x);
                        return;
                    }
                }
            }else {
                simulator->getReserva()->criaAlimento(foodType, y, x);
                return;
            }
            //PASSAR COORDENADAS RANDOM QUANDO N SAO DADAS PELO USER

            return ;
        }

        printMessages << "[ERRO] Tipo de alimento errado";
        printMessages.clear();
    }else{
        if(foodType == 'r'){//r t b a
            if(!simulator->getReserva()->getAlimentoVector().empty()){
                for(int i = 0; i < simulator->getReserva()->getAlimentoVector().size(); i++) {
                    if (simulator->getReserva()->getAlimentoVector()[i]->getY() == l && simulator->getReserva()->getAlimentoVector()[i]->getX() == c){
                        printMessages << "Ja existe um alimento neste sitio";
                        printMessages.clear();
                        return;
                    }
                    else{
                        simulator->getReserva()->criaAlimento(foodType, l, c);
                        return;
                    }
                }
            }else{
                simulator->getReserva()->criaAlimento(foodType, l, c);
                return;
            }

            return;
        }

        if(foodType == 't'){//r t b a
            if(!simulator->getReserva()->getAlimentoVector().empty()){
                for(int i = 0; i < simulator->getReserva()->getAlimentoVector().size(); i++) {
                    if (simulator->getReserva()->getAlimentoVector()[i]->getY() == l && simulator->getReserva()->getAlimentoVector()[i]->getX() == c){
                        printMessages << "Ja existe um alimento neste sitio";
                        printMessages.clear();
                        return;
                    }
                    else{
                        simulator->getReserva()->criaAlimento(foodType, l, c);
                        return;
                    }
                }
            }else{
                simulator->getReserva()->criaAlimento(foodType, l, c);
                return;
            }

            return;
        }

        if(foodType == 'p'){//r t b a
            if(!simulator->getReserva()->getAlimentoVector().empty()){
                for(int i = 0; i < simulator->getReserva()->getAlimentoVector().size(); i++) {
                    if (simulator->getReserva()->getAlimentoVector()[i]->getY() == l && simulator->getReserva()->getAlimentoVector()[i]->getX() == c){
                        printMessages << "Ja existe um alimento neste sitio";
                        printMessages.clear();
                        return;
                    }
                    else{
                        simulator->getReserva()->criaAlimento(foodType, l, c);
                        return;
                    }
                }
            }else{
                simulator->getReserva()->criaAlimento(foodType, l, c);
                return;
            }

            return;
        }

        if(foodType == 'b'){//r t b a
            if(!simulator->getReserva()->getAlimentoVector().empty()){
                for(int i = 0; i < simulator->getReserva()->getAlimentoVector().size(); i++) {
                    if (simulator->getReserva()->getAlimentoVector()[i]->getY() == l && simulator->getReserva()->getAlimentoVector()[i]->getX() == c){
                        printMessages << "Ja existe um alimento neste sitio";
                        printMessages.clear();
                        return;
                    }
                    else{
                        simulator->getReserva()->criaAlimento(foodType, l, c);
                        return;
                    }
                }
            }else{
                simulator->getReserva()->criaAlimento(foodType, l, c);
                return;
            }

            return ;
        }

        if(foodType == 'a'){//r t b a
            if(!simulator->getReserva()->getAlimentoVector().empty()){
                for(int i = 0; i < simulator->getReserva()->getAlimentoVector().size(); i++) {
                    if (simulator->getReserva()->getAlimentoVector()[i]->getY() == l && simulator->getReserva()->getAlimentoVector()[i]->getX() == c){
                        printMessages << "Ja existe um alimento neste sitio";
                        printMessages.clear();
                        return;
                    }
                    else{
                        simulator->getReserva()->criaAlimento(foodType, l, c);
                        return;
                    }
                }
            }else{
                simulator->getReserva()->criaAlimento(foodType, l, c);
                return;
            }

            return ;
        }

        printMessages << "[ERRO] Tipo de alimento errado";
        printMessages.clear();

    }
}

void Interface::commandEmpty(int l, int c) {

    if(!simulator->getVecAnimal().empty()){
        simulator->getReserva()->killAnimalByPosition(l, c);
        simulator->getReserva()->killFoodByPosition(l, c);
    }else {
        printMessages << "[ERRO] Reserva vazia, nao e possivel apagar os elementos dessa zona";
        printMessages.clear();
    }
}

void Interface::commandSee(int l, int c) {

    commandsResult << "[COMANDO SEE]\n";

    commandsResult << "Posicao (" << l << "," << c << ")\n";
    if(!simulator->getReserva()->getAnimalVector().empty()){
        commandsResult << "Animais: \n";
        for(auto a:simulator->getReserva()->getAnimalVector()){
            if(a->getY() == l && a->getX() == c){
                commandsResult << a->getAnimalAsString();
                commandsResult << "------------------------\n";
            }
        }
    }else{
        commandsResult << "Animais: \n";
        commandsResult << "Nao existem animais\n";
    }

    if(!simulator->getReserva()->getAlimentoVector().empty()){
        commandsResult << "Alimentos: \n";
        for(auto a: simulator->getReserva()->getAlimentoVector()){
            if(a->getY() == l && a->getX() == c){
                commandsResult << a->getAlimentosAsString();
                commandsResult << "------------------------\n";
            }
        }
    }else{
        commandsResult << "Alimentos: \n";
        commandsResult << "Nao existem alimentos";
    }
}

void Interface::commandInfo(int id) {

    int i = 0;

    commandsResult << "[COMANDO INFO]\n";

    for(auto a : simulator->getReserva()->getAnimalVector()){
        if(a->getID() == id){
            commandsResult << a->getAnimalAsString();
            i = 1;
        }
    }

    for(auto a : simulator->getReserva()->getAlimentoVector()){
        if(a->getID() == id){
            commandsResult << a->getAlimentosAsString();
            i = 1;
        }
    }

    if(i == 0){
        printMessages << "[ERRO] Nao existe nenhum elemento da Reserva com este ID";
        printMessages.clear();
    }

}

void Interface::commandFeed(int l, int c, int nutritionPoints, int toxicityPoints) {

    for(auto a: simulator->getReserva()->getAnimalVector()){
        if(a == simulator->getAnimalByPosition(l, c)){
            simulator->getReserva()->feedAnimalByPosition(l, c, nutritionPoints, toxicityPoints);
        }
    }

}

void Interface::commandFeedID(int id, int nutritionPoints, int toxicityPoints) {

    for(auto a: simulator->getReserva()->getAnimalVector()){
        if(a->getID() == id){
            simulator->getReserva()->feedAnimalById(id, nutritionPoints, toxicityPoints);
        }
    }

}

void Interface::commandNoFood(int l, int c, int id) {

    if(id == 0){
        simulator->getReserva()->killFoodByPosition(l, c);
    }

    if(l == 0 && c == 0){
        simulator->getReserva()->killFoodByID(id);
    }
}

void Interface::commandReStore(string name) {

    string msg;
    msg = simulator->ReStore(name);

    printMessages << msg;
    printMessages.clear();
}

void Interface::commandStore(string name){

    string msg;
    msg = simulator->Store(name);

    printMessages << msg;
    printMessages.clear();
}

void Interface::commandVisAnim(){

    for(auto a: simulator->getReserva()->getAnimalVector()){
        if((a->getY() >= _down &&  a->getY() <= _down + 10 )&& (a->getX() >= _right && a->getX() <= _right + 10)){
            commandsResult << a->getAnimalAsString();
        }
    }
}

void Interface::commandAnim(){

    commandsResult << "[COMANDO ANIM]\n";
    commandsResult << simulator->getReserva()->getAnimalVectorAsString();

}

void Interface::commandLoad(const string& filename) {

    //ostringstream oss;
    //oss << "../" << filename;

    ifstream file(filename);
    //ifstream file(oss.str());

    if (file.is_open() && file.good()) {
        string phrase;

        while (getline(file, phrase) || !file.eof()) {
            vector<string> commandsDivided = divideString((phrase));
            istringstream iss(phrase);

            string command;
            iss >> command;

            if (command == "animal") {

                char animalType;
                if (iss >> animalType) {

                    if (commandsDivided.size() <= 2) {
                        commandAnimal(animalType, 0, 0);
                    } else {
                        int line;
                        if (iss >> line) {

                            int column;
                            if (iss >> column) {
                                commandAnimal(animalType, line, column);
                            } else {
                                printMessages << "[ERRO] Argumento invalido! Introduza uma coluna";
                                printMessages.clear();
                            }

                        } else {
                            printMessages << "[ERRO] Argumento invalido! Introduza uma linha";
                            printMessages.clear();
                        }

                    }
                } else {
                    printMessages << "[ERRO] Argumento invalido! Introduza o tipo de animal";
                    printMessages.clear();
                }

            }

            if(command == "kill"){

                int line;
                if(iss >> line){

                    int column;
                    if(iss >> column){
                        commandKill(line, column);
                    }else {
                        printMessages << "[ERRO] Argumento invalido! Introduza uma coluna correta";
                        printMessages.clear();
                    }
                }else {
                    printMessages << "[ERRO] Argumento invalido! Introduza uma linha correta";
                    printMessages.clear();
                }

            }

            if(command == "killid"){

                int id;
                if(iss >> id){
                    commandKillId(id);
                }else {
                    printMessages << "[ERRO] Argumento invalido! Introduza um id correto";
                    printMessages.clear();
                }

            }

            if (command == "food") {

                char foodType;
                if (iss >> foodType) {

                    if (commandsDivided.size() <= 2) {
                        commandFood(foodType, 0, 0);
                    } else {
                        int line;
                        if (iss >> line) {

                            int column;
                            if (iss >> column) {
                                commandFood(foodType, line, column);
                            } else {
                                printMessages << "[ERRO] Argumento invalido! Introduza uma coluna";
                                printMessages.clear();
                            }

                        } else {
                            printMessages << "[ERRO] Argumento invalido! Introduza uma linha";
                            printMessages.clear();
                        }

                    }
                } else {
                    printMessages << "[ERRO] Argumento invalido! Introduza o tipo de comida";
                    printMessages.clear();
                }

            }

            if(command == "feed"){

                int line;
                if(iss >> line){

                    int column;
                    if(iss >> column){

                        int nutritionPoints;
                        if(iss >> nutritionPoints){

                            int toxicityPoints;
                            if(iss >> toxicityPoints){
                                commandFeed(line, column, nutritionPoints, toxicityPoints);
                            }else {
                                printMessages << "[ERRO] Introduza Pontos de Toxicidade";
                                printMessages.clear();
                            }
                        }else {
                            printMessages << "[ERRO] Introduza Pontos de Nutricao";
                            printMessages.clear();
                        }
                    }else {
                            printMessages << "[ERRO] Introduza uma coluna correta";
                            printMessages.clear();
                        }
                }else {
                    printMessages << "[ERRO] Introduza uma linha correta";
                    printMessages.clear();
                }
            }

            if(command == "feedid"){

                int id;
                if(iss >> id){

                    int nutritionPoints;
                    if(iss >> nutritionPoints){

                        int toxicityPoints;
                        if(iss >> toxicityPoints){
                            commandFeedID(id, nutritionPoints, toxicityPoints);
                        }else {
                            printMessages << "[ERRO] Introduza Pontos de Toxicidade";
                            printMessages.clear();
                        }
                    }else {
                        printMessages << "[ERRO] Introduza Pontos de Nutricao";
                        printMessages.clear();
                    }
                }else {
                    printMessages << "[ERRO] Introduza um id correto";
                    printMessages.clear();
                }
            }

            if(command == "nofood"){

                if(commandsDivided.size() == 3){
                    int line;
                    if(iss >> line){

                        int column;
                        if(iss >> column){
                            commandNoFood(line, column, 0);
                        }else {
                            printMessages << "[ERRO] Argumento invalido! Introduza uma coluna correta";
                            printMessages.clear();
                        }
                    }else {
                        printMessages << "[ERRO] Argumento invalido! Introduza uma linha correta";
                        printMessages.clear();
                    }
                }

                if(commandsDivided.size() == 2){
                    int id;
                    if(iss >> id){
                        commandNoFood(0, 0 , id);
                    }else {
                        printMessages << "[ERRO] Argumento invalido! Introduza um id correto";
                        printMessages.clear();
                    }
                }
            }

            if(command == "empty"){

                int line;
                if(iss >> line){

                    int column;
                    if(iss >> column){
                        commandEmpty(line, column);
                    }else {
                        printMessages << "[ERRO] Argumento invalido! Introduza uma coluna";
                        printMessages.clear();
                    }
                }else {
                    printMessages << "[ERRO] Argumento invalido! Introduza uma linha";
                    printMessages.clear();
                }
            }

            if (command == "see") {

                int line;
                if (iss >> line) {

                    int column;
                    if (iss >> column) {
                        commandSee(line, column);
                    } else {
                        printMessages << "[ERRO] Indique uma coluna correta";
                        printMessages.clear();
                    }

                } else {
                    printMessages << "[ERRO] Indique uma linha correta";
                    printMessages.clear();
                }
            }

            if (command == "info") {

                int id;
                if (iss >> id) {
                    commandInfo(id);
                } else {
                    printMessages << "[ERRO] Indique um id correto";
                    printMessages.clear();
                }
            }

            if(command == "n"){

                if(commandsDivided.size() == 1){
                    commandNext();
                }else if(commandsDivided.size() == 2) {

                    int N;
                    if(iss >> N){
                        commandNextN(N);
                    }else {
                        printMessages << "[ERRO] Indique uma quantidade de instantes";
                        printMessages.clear();
                    }
                }else if(commandsDivided.size() == 3){

                    int N;
                    if(iss >> N){

                        int P;
                        if(iss >> P){
                            commandNextNP(N, P);
                        }else {
                            printMessages << "[ERRO] Indique uma quantidade de instantes que pretende esperar entre cada instante";
                            printMessages.clear();
                        }
                    }else {
                        printMessages << "[ERRO] Indique uma quantidade de instantes";
                        printMessages.clear();
                    }
                }

            }

            if (command == "anim") {
                commandAnim();
            }

            if(command == "visanim"){
                commandVisAnim();
            }

            if(command == "store"){

                string name;
                if(iss >> name){
                    commandStore(name);
                }else {
                    printMessages << "[ERRO] Introduza um nome para o save";
                    printMessages.clear();
                }
            }

            if(command == "restore"){
                string name;
                if(iss >> name){
                    commandReStore(name);
                }else {
                    printMessages << "[ERRO] Introduza um nome de um save";
                    printMessages.clear();
                }
            }

            if (command == "load") {

                string nome_fich;
                if (iss >> nome_fich) {
                    commandLoad(nome_fich);
                }else {
                    printMessages << "[ERRO] Introduza um nome para o save";
                    printMessages.clear();
                }
            }

            if(command == "slide"){

                string direction;
                if(iss >> direction){
                    if(direction != "up" &&
                       direction != "down" &&
                       direction != "right" &&
                       direction != "left")
                    {
                        printMessages << "[ERRO] Insira uma direcao correta (up/down/right/left)";
                        printMessages.clear();
                        return;
                    }

                    commandSlide(direction);
                }else {
                    printMessages << "Insira uma direcao correta (up/down/right/left)";
                    printMessages.clear();
                }

            }

            if(command == "exit"){
                readCommandsFromKeyboard("exit");
            }
        }
        file.close();
    }
}

string Interface::readCommandsFromKeyboard(string fullCommand){
    vector<string> commandsDivided = divideString((fullCommand));
    istringstream iss(fullCommand);

    string command;
    iss >> command;

    if(command == "animal"){

        char animalType;
        if(iss >> animalType){

            if(commandsDivided.size() <= 2){
                commandAnimal(animalType, 0 , 0);
            }else{
                int line;
                if(iss >> line){

                    int column;
                    if(iss >> column){
                        commandAnimal(animalType, line, column);
                    }else {
                        printMessages << "[ERRO] Argumento invalido! Introduza uma coluna";
                        printMessages.clear();
                    }

                }else {
                    printMessages << "[ERRO] Argumento invalido! Introduza uma linha";
                    printMessages.clear();
                }
            }
        }else{
                printMessages << "[ERRO] Argumento invalido! Introduza o tipo de animal";
                printMessages.clear();
            }

        return command;
    }

    if(command == "kill"){

        int line;
        if(iss >> line){

            int column;
            if(iss >> column){
                commandKill(line, column);
            }else {
                printMessages << "[ERRO] Argumento invalido! Introduza uma coluna correta";
                printMessages.clear();
            }
        }else{
                printMessages << "[ERRO] Argumento invalido! Introduza uma linha correta";
                printMessages.clear();
            }

        return command;
    }

    if(command == "killid"){

        int id;
        if(iss >> id){
            commandKillId(id);
        }else {
            printMessages << "[ERRO] Argumento invalido! Introduza um id correto";
            printMessages.clear();
        }

        return command;
    }

    if(command == "food"){

        char foodType;
        if(iss >> foodType){

            if(commandsDivided.size() <= 2){
                commandFood(foodType, 0 , 0);
            }else{
                int line;
                if(iss >> line){

                    int column;
                    if(iss >> column){
                        commandFood(foodType, line, column);
                    }else {
                        printMessages << "[ERRO] Argumento invalido! Introduza uma coluna";
                        printMessages.clear();
                    }

                }else{
                    printMessages << "[ERRO] Argumento invalido! Introduza uma linha";
                    printMessages.clear();
                }

            }
        }else {
            printMessages << "[ERRO] Argumento invalido! Introduza o tipo de comida";
            printMessages.clear();
        }

        return command;
    }

    if(command == "feed"){

        int line;
        if(iss >> line){

            int column;
            if(iss >> column){

                int nutritionPoints;
                if(iss >> nutritionPoints){

                    int toxicityPoints;
                    if(iss >> toxicityPoints){
                        commandFeed(line, column, nutritionPoints, toxicityPoints);
                    }else {
                        printMessages << "[ERRO] Introduza Pontos de Toxicidade";
                        printMessages.clear();
                    }
                }else {
                    printMessages << "[ERRO] Introduza Pontos de Nutricao";
                    printMessages.clear();
                }
            }else {
                printMessages << "[ERRO] Introduza uma coluna correta";
                printMessages.clear();
            }
        }else {
            printMessages << "[ERRO] Introduza uma linha correta";
            printMessages.clear();
        }

        return command;
    }

    if(command == "feedid"){

        int id;
        if(iss >> id){

            int nutritionPoints;
            if(iss >> nutritionPoints){

                int toxicityPoints;
                if(iss >> toxicityPoints){
                    commandFeedID(id, nutritionPoints, toxicityPoints);
                }else {
                    printMessages << "[ERRO] Introduza Pontos de Toxicidade";
                    printMessages.clear();
                }
            }else {
                printMessages << "[ERRO] Introduza Pontos de Nutricao";
                printMessages.clear();
            }
        }else {
            printMessages << "[ERRO] Introduza um id correto";
            printMessages.clear();
        }

        return command;
    }

    if(command == "nofood"){

        if(commandsDivided.size() == 3){
            int line;
            if(iss >> line){

                int column;
                if(iss >> column){
                    commandNoFood(line, column, 0);
                }else {
                    printMessages << "[ERRO] Argumento invalido! Introduza uma coluna correta";
                    printMessages.clear();
                }
            }else {
                printMessages << "[ERRO] Argumento invalido! Introduza uma linha correta";
                printMessages.clear();
            }
        }

        if(commandsDivided.size() == 2){
            int id;
            if(iss >> id){
                commandNoFood(0, 0 , id);
            }else {
                printMessages << "[ERRO] Argumento invalido! Introduza um id correto";
                printMessages.clear();
            }
        }

        return command;
    }

    if(command == "empty"){

        int line;
        if(iss >> line){

            int column;
            if(iss >> column){
                commandEmpty(line, column);
            }else {
                printMessages << "[ERRO] Argumento invalido! Introduza uma coluna";
                printMessages.clear();
            }
        }else {
            printMessages << "[ERRO] Argumento invalido! Introduza uma linha";
            printMessages.clear();
        }

        return command;
    }

    if(command == "see"){

        int line;
        if(iss >> line){

            int column;
            if(iss >> column){
                commandSee(line, column);
            }else {
                printMessages << "[ERRO] Indique uma coluna correta";
                printMessages.clear();
            }

        }else {
            printMessages << "[ERRO] Indique uma linha correta";
            printMessages.clear();
        }

        return command;
    }

    if(command == "info"){

        int id;
        if(iss >> id){
            commandInfo(id);
        }else {
            printMessages << "[ERRO] Indique um id correto";
            printMessages.clear();
        }

        return command;
    }

    if(command == "n"){

        if(commandsDivided.size() == 1){
            commandNext();
        }else if(commandsDivided.size() == 2) {

            int N;
            if(iss >> N){
                commandNextN(N);
            }else {
                printMessages << "[ERRO] Indique uma quantidade de instantes";
                printMessages.clear();
            }
        }else if(commandsDivided.size() == 3){

            int N;
            if(iss >> N){

                int P;
                if(iss >> P){
                    commandNextNP(N, P);
                }else {
                    printMessages << "[ERRO] Indique uma quantidade de instantes que pretende esperar entre cada instante";
                    printMessages.clear();
                }
            }else {
                printMessages << "[ERRO] Indique uma quantidade de instantes";
                printMessages.clear();
            }
        }

    }

    if(command == "anim"){
        commandAnim();
        return command;
    }

    if(command == "visanim"){
        commandVisAnim();
        return command;
    }

    if(command == "store"){

        string name;
        if(iss >> name){
            commandStore(name);
        }else {
            printMessages << "[ERRO] Introduza um nome para o save";
            printMessages.clear();
        }

        return command;
    }

    if(command == "restore"){
        string name;
        if(iss >> name){
            commandReStore(name);
        }else {
            printMessages << "[ERRO] Introduza um nome de um save";
            printMessages.clear();
        }

        return command;
    }

    if(command == "load"){

        string nome_fich;
        if(iss >> nome_fich){
            commandLoad(nome_fich);
        }else {
            printMessages << "[ERRO] Indique o nome de um ficheiro";
        }

        return command;

    }

    if(command == "slide"){

        string direction;
        if(iss >> direction){
            if(direction != "up" &&
               direction != "down" &&
               direction != "right" &&
               direction != "left")
            {
                printMessages << "[ERRO] Insira uma direcao correta (up/down/right/left)";
                printMessages.clear();
                return command;
            }

            commandSlide(direction);
        }else{
            printMessages << "[ERRO] Insira uma direcao correta (up/down/right/left)";
            printMessages.clear();
        }

        return command;

    }

    if(command == "exit"){
        return command;
    }

    return "";
}

void Interface::board(){ //FIX SLIDE SPACES

    //reserva << move_to(1, 1)<< "\t=========================================\n";
    //reserva << "\t=\t\t  RESERVA\t\t=\n";
    //reserva << "\t=========================================\n\n\n\n\n" ;

    reserva << move_to(0, 0);
    reserva << "[AVISO] + -> existe mais que um animal naquela zone (utilize comando see linha coluna)";

    int line = 1;
    reserva << move_to(1, line);
    for(int a = 0; a < 10; a++){
        line++;
        reserva << "*";
        for(int b = 0; b < 10; b++) {
            for (int i = 0; i < 8; i++) {
                reserva << "*";
            }
        }

        reserva << move_to(1, line);

        int offsetJ = 8;
        for(int b = 0; b < 10; b++) {

            reserva << "*" << a + 1 + _down << "," << b + 1 + _right << "";

            if((a + 1) < 10 && (b + 1) < 10){
                reserva << "    ";
            }else if((a + 1) < 10 && (b + 1) >= 10 && (b + 1) < 100){
                reserva << "   ";
            }else if((a + 1) < 10 && (b + 1) > 100){
                reserva << "  ";
            }else if((a + 1) >= 10 && (b + 1) < 10){
                reserva << "   ";
            }else if((a + 1) >= 10 && (b + 1) >= 10 && (b + 1) < 100) {
                reserva << "  ";
            }else if((a + 1) >= 10 && (b + 1) >= 100){
                reserva << " ";
            }else if((a + 1) >= 100 && (b + 1) < 10){
                reserva << "  ";
            }else if((a + 1) >= 100 && (b + 1) >= 10 && (b + 1) < 100){
                reserva << " ";
            }else if((a + 1) >= 100 && (b + 1) >= 100){
                reserva << "";
            }else
                continue;

            reserva << move_to(offsetJ, line);
            offsetJ += 8;
        }
        line++;
        reserva << "*";
        reserva << move_to(1, line);
        //1a LINHA COM COORDS

        //LINHA DOS ANIMAIS
        int offsetK = 8;

        for(int b = 0; b < 10; b++) {

            if(b == 0){
                reserva << move_to(1, line);
            }
            reserva << "*";
            int num_animals_space = 0;
            int num_spaces = 7;
            for(int c = 0; c < simulator->getReserva()->getAnimalVector().size(); c++){
                if(simulator->getReserva()->getAnimalVector()[c]->getY() == (a + 1 + _down) && simulator->getReserva()->getAnimalVector()[c]->getX() == (b + 1 + _right)){
                    if(num_animals_space >= 1){
                        reserva << move_to(offsetK - 7, line);
                        reserva << "+";
                        ++num_animals_space;
                        --num_spaces;
                        continue;
                    }

                    reserva << move_to(offsetK - 7, line);
                    reserva << simulator->getReserva()->getAnimalVector()[c]->getAbreviation();
                    ++num_animals_space;
                    --num_spaces;
                }
            }

            if(num_animals_space > 0){
                for(int d = 0; d < num_spaces; d++){
                    reserva << " ";
                    if((d + num_animals_space) == 7){
                        break;
                    }
                }
            }else
                reserva << "       ";

            reserva << move_to(offsetK, line);
            offsetK += 8;
        }
        line++;
        reserva << "*";
        reserva << move_to(1, line);

        //LINHA DOS ALIMENTOS
        int offsetL = 8;
        for(int b = 0; b < 10; b++) {

            if(b == 0){
                reserva << move_to(1, line);
            }

            reserva << "*";
            int num_alimentos_space = 0;
            int num_spaces = 7;
            for(int c = 0; c < simulator->getReserva()->getAlimentoVector().size(); c++){
                if(simulator->getReserva()->getAlimentoVector()[c]->getY() == (a + 1 + _down) && simulator->getReserva()->getAlimentoVector()[c]->getX() == (b + 1 + _right)){
                    if(num_alimentos_space >= 1){
                        reserva << move_to(offsetK - 7, line);
                        reserva << "+";
                        ++num_alimentos_space;
                        --num_spaces;
                        continue;
                    }

                    reserva << move_to(offsetL - 7, line);
                    reserva << simulator->getReserva()->getAlimentoVector()[c]->getAbreviation();
                    ++num_alimentos_space;
                    --num_spaces;
                }
            }

            if(num_alimentos_space > 0){
                for(int d = 0; d < num_spaces; d++){
                    reserva << " ";
                    if((d + num_alimentos_space) == 7){
                        break;
                    }
                }
            }else
                reserva << "       ";

            reserva << move_to(offsetL, line);
            offsetL += 8;
        }
        line++;
        reserva << "*";
        reserva << move_to(1, line);
        //LINHA DOS ALIMENTOS
    }
    line++;
    reserva << "*";
    reserva << move_to(1, line);

    for(int b = 0; b < 10; b++) {
        for (int i = 0; i < 8; i++) {
            reserva << "*";
        }
    }
    reserva << "*";
}

void Interface::run(){
    srand (time(NULL));

     commands << move_to(51, 0) << "----------> BEM VINDO A RESERVA NATURAL!!!! <----------";

    string answer;
    string filename;
    int nl = 0, nc = 0;
    string numl, numc;

    simulator->readConstantes();

    //OBTENCAO DE NC E NL
    do{

        commands << "\nInsira um Numero de Linhas: (NL)\n";
        commands >> numl;
        istringstream iss(numl);


        if(iss >> nl){}
        commands.clear();

        if(nl < 16 || nl > 500) {
            printMessages << "\n[ERRO] Numero de linhas entre 16 e 500\n";
            printMessages.clear();
            continue;
        }

        commands << "\nInsira um Numero de Colunas: (NC)\n";
        commands >> numc;
        istringstream iss2(numc);

        if(iss2 >> nc){}
        commands.clear();

        if(nc < 16 || nc > 500) {
            printMessages << "\n[ERRO] Numero de colunas entre 16 e 500\n";
            printMessages.clear();
            continue;
        }


    }while((nl < 16 || nc < 16) || (nl > 500 || nc > 500));

    simulator->getReserva()->setNL(nl);
    simulator->getReserva()->setNC(nc);

    string cmd;

    //commands << move_to(0, 0) << "[COMANDOS] Insira os comandos que pretende executar? \n";

    do{
        commands << "[COMANDOS] Insira os comandos que pretende executar? \n";
        commands >> answer;


        cmd = readCommandsFromKeyboard(answer);

        board();

        //interfaceStatus = getInterfaceAsString();
        stateReserva << move_to(1,1);
        stateReserva << getInterfaceAsString();
        stateReserva.clear();

        string a;
        a.resize(200);
        reserva >> a;

        if (a == "KEY_UP") {
            if( _down>0 ) _down--;
            commands.clear();
            reserva.clear();
            continue;
        }
        if (a == "KEY_DOWN") {
            if( _down<t.getNumRows()-5 ) _down++;
            commands.clear();
            reserva.clear();
            continue;
        }
        if (a == "KEY_LEFT") {
            if( _right>0 ) _right--;
            commands.clear();
            reserva.clear();
            continue;
        }
        if (a == "KEY_RIGHT") {
            if( _right<t.getNumCols()-30 ) _right++;
            commands.clear();
            reserva.clear();
            continue;
        }

        commands.clear();
        reserva.clear();
        stateReserva.clear();
        printMessages.clear();
        commandsResult.clear();

    }while(cmd != "exit");

}

string Interface::getInterfaceAsString() const{
    ostringstream oss;

    oss << "-------------------------------" << endl
        << "| DETALHES ATUAIS DO TABULEIRO: |" << endl
        << " -------------------------------" << endl << endl
        << "Animais: " << endl << simulator->getReserva()->getAnimalVectorAsString() << endl
        << "Alimento: " << endl << simulator->getReserva()->getAlimentosVectorAsString() << endl
        << "Numero animais: "  << simulator->getReserva()->getAnimalVector().size() << endl
        << "Quantidade de Comida Disponivel: " << simulator->getReserva()->getAlimentoVector().size() << endl
        << "Segundos: " << simulator->getReserva()->getSeconds() << endl;


    return oss.str();
}
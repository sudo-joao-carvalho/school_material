//
// Created by João Carvalho on 10/12/2022.
//

#ifndef TP_POO_22_23_SIMULADOR_H
#define TP_POO_22_23_SIMULADOR_H

#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <map>
#include "Reserva.h"

using namespace std;

class Alimento;
class Animal;
class Reserva;
//class Simulador;

class Simulador{

public:
    explicit Simulador(Reserva* r);
    Simulador(const Simulador& sim);

    void readConstantes();

    Reserva* getReserva() const;

    static void setConstAbreviation(const string& animalType, char character);
    static void setConstLife(const string& animalType, int health);
    static void setConstLifeTime(const string& animalType, int moments);

    static char getN(char abrv);
    static int getS(char abrv);
    static int getV(char abrv);
    Animal* getAnimalByPosition(int y, int x) const;
    vector<Animal*> getVecAnimal() const;

    string Store(string name);
    string ReStore(string name);

private:

    Reserva* reserva;

    static char NCoelho; //as vars de cada tipo depois passam para as respetivas classes derivadas
    static int SCoelho;
    static int VCoelho;
    static char NOvelha;
    static int SOvelha;
    static int VOvelha;
    static char NLobo;
    static int SLobo;
    static int VLobo;
    static char NCanguru;
    static int SCanguru;
    static int VCanguru;
    static char NMisterio;
    static int SMisterio;
    static int VMisterio;

    map<string, Reserva*> saves;

    int seconds;
};

#endif //TP_POO_22_23_SIMULADOR_H

//
// Created by João Carvalho on 10/12/2022.
//

#include "Simulador.h"
#include "Interface.h"
#include <fstream>

char Simulador::NCoelho = 'a';
int Simulador::SCoelho = 0;
int Simulador::VCoelho = 0;
char Simulador::NOvelha = 'a';
int Simulador::SOvelha  = 0;
int Simulador::VOvelha = 0;
char Simulador::NLobo = 'a';
int Simulador::SLobo = 0;
int Simulador::VLobo = 0;
char Simulador::NCanguru = 'a';
int Simulador::SCanguru = 0;
int Simulador::VCanguru = 0;
char Simulador::NMisterio = 'a';
int Simulador::SMisterio = 0;
int Simulador::VMisterio = 0;

Simulador::Simulador(Reserva *r): reserva(r), seconds(0) {
}

Simulador::Simulador(const Simulador &sim) {
    *this = sim;
}

string Simulador::ReStore(string name) {

     auto it = saves.find(name);

     if(it != saves.end()){

         reserva = it->second;

         return "Gravacao com o nome " + name + " foi ativa com sucesso";
     }

    return "[ERRO] Nenhum save com o nome " + name;
}

string Simulador::Store(string name) {

    if(saves.find(name) != saves.end()){
        return"[ERRO] Ja existe uma save com o nome " + name;
    }

    Reserva* tmp = new Reserva(*reserva);
    saves.insert(pair<string, Reserva*>(name, tmp));

    return "Foi criado um save com o nome " + name;

}

Reserva *Simulador::getReserva() const {
    return reserva;
}

void Simulador::readConstantes() { //ler ficheiro de constantes aqui

    //ofstream file1("out_test.txt");
    //ostringstream oss;
    //oss << "../" << "constantes.txt";

    //ifstream file("/Users/joaocarvalho/Desktop/Universidade/2oAno/POO/TP-POO-22-23/cmake-build-debug/constantes.txt");
    //ifstream file(oss.str());
    ifstream file("constantes.txt");

    if(file.is_open() && file.good()) {
        string line;

        while (getline(file, line) || !file.eof()) {
            istringstream  iss(line);
            string animalType;

            iss >> animalType;

            if(line.substr(0,1) == "N"){
                char character;
                iss >> character;
                tolower(character);

                Simulador::setConstAbreviation(animalType, character);
            }

            if(line.substr(0,1) == "S"){
                int life;
                iss >> life;

                Simulador::setConstLife(animalType, life);
            }

            if(line.substr(0,1) == "V"){
                int lifeTime;
                iss >> lifeTime;

                Simulador::setConstLifeTime(animalType, lifeTime);
            }
        }
    }
    //cout << "Ficheiro de constantes lido" << endl;
    file.close();
}

void Simulador::setConstAbreviation(const string& animalType, char character) {
    if(animalType == "NCoelho")
        NCoelho = character;

    if(animalType == "NOvelha")
        NOvelha = character;

    if(animalType == "NLobo")
        NLobo = character;

    if(animalType == "NCanguru")
        NCanguru = character;

    if(animalType == "NMisterio")
        NMisterio = character;
}

void Simulador::setConstLife(const string& animalType, int health) {

    if (animalType == "SCoelho") {
        SCoelho = health;
    }

    if(animalType == "SOvelha") {
        SOvelha = health;
    }

    if(animalType == "SLobo") {
        SLobo = health;
    }

    if(animalType == "SCanguru"){
        SCanguru = health;
    }

    if(animalType == "SMisterio"){
        SMisterio = health;
    }


}

void Simulador::setConstLifeTime(const string& animalType, int moments) {

    if(animalType == "VCoelho")
        VCoelho = moments;

    if(animalType == "VOvelha")
        VOvelha = moments;

    if(animalType == "VLobo")
        VLobo = moments;

    if(animalType == "VCanguru")
        VCanguru = moments;

    if(animalType == "VMisterio")
        VMisterio = moments;

}

char Simulador::getN(char abrv) {
    if(abrv == 'c'){
        return NCoelho;
    }

    if(abrv == 'o'){
        return NOvelha;
    }

    if(abrv == 'l'){
        return NLobo;
    }

    if(abrv == 'g'){
        return NCanguru;
    }

    if(abrv == 'm'){
        return NMisterio;
    }

    return '\0';
}

int Simulador::getS(char abrv) {
    if(abrv == 'c'){
        return SCoelho;
    }

    if(abrv == 'o'){
        return SOvelha;
    }

    if(abrv == 'l'){
        return SLobo;
    }

    if(abrv == 'g'){
        return SCanguru;
    }

    if(abrv == 'm'){
        return SMisterio;
    }

    return 0;
}

int Simulador::getV(char abrv) {
    if(abrv == 'c'){
        return VCoelho;
    }

    if(abrv == 'o'){
        return VOvelha;
    }

    if(abrv == 'l'){
        return VLobo;
    }

    if(abrv == 'g'){
        return VCanguru;
    }

    if(abrv == 'm'){
        return VMisterio;
    }

    return 0;
}

Animal *Simulador::getAnimalByPosition(int y, int x) const {
    for(auto a: reserva->getAnimalVector()){
        if(a->getY() == y && a->getX() == x)
            return a;
        else continue;
    }
    return nullptr;
}

vector<Animal*> Simulador::getVecAnimal() const{
    return reserva->getAnimalVector();
}

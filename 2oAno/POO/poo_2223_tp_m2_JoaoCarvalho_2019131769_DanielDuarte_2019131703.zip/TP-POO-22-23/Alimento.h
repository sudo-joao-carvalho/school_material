//
// Created by João Carvalho on 07/11/2022.
//

#ifndef TP_POO_22_23_ALIMENTO_H
#define TP_POO_22_23_ALIMENTO_H

#include <iostream>
#include <sstream>
#include <string>
#include <sstream>
#include <vector>

using namespace std;

class Alimento{
public:
    Alimento(char& abreviation, int id, int y, int x);
    ~Alimento();

    char getAbreviation() const;
    int getID() const;
    int  getlifeTime() const;
    int getNutValue() const;
    int getToxicity() const;
    vector<string> getSmell() const;//por vetor
    int getY() const;
    int getX() const;

    string getAlimentosAsString() const;

    void setID(int number);


protected:
    char abreviation;
    int id;

    int y;
    int x;
};

/*
 * Relva
 * Cenoura
 * Corpo
 * Bife
 * AlimentoM*/

class Relva:public Alimento{
public:
    Relva(char& abreviation, int id, int y, int x);
private:
    int lifeTime;
    int nutValue;
    int toxicity;
    vector<string> smell;
};

class Cenoura:public Alimento{
public:
    Cenoura(char& abreviation, int id, int y, int x);
private:
    int lifeTime;
    int nutValue;
    int toxicity;
    vector<string> smell;
};

class Corpo:public Alimento{
public:
    Corpo(char& abreviation, int id, int y, int x);
private:
    int lifeTime;
    int nutValue;
    int toxicity;
    vector<string> smell;
};
class Bife:public Alimento{
public:
    Bife(char& abreviation, int id, int y, int x);
private:
    int lifeTime;
    int nutValue;
    int toxicity;
    vector<string> smell;
};

class AlimentoM:public Alimento{
public:
    AlimentoM(char& abreviation, int id, int y, int x);
private:
    int lifeTime;
    int nutValue;
    int toxicity;
    vector<string> smell;
};


#endif //TP_POO_22_23_ALIMENTO_H

//
// Created by João Carvalho on 07/11/2022.
//

#include "Alimento.h"

Alimento::Alimento(char& abrv, int id, int y, int x):abreviation(abrv), id(id), y(y), x(x){
    //cout << "Alimento criado com sucesso" << endl;
}

Alimento::~Alimento() {

}

void Alimento::setID(int number){
    id = number;
}

int Alimento::getID() const {
    return id;
}

char Alimento::getAbreviation() const {
    return abreviation;
}

/*int Alimento::getlifeTime() const {
    return lifeTime;
}

int Alimento::getNutValue() const {
    return nutValue;
}

int Alimento::getToxicity() const {
    return toxicity;
}

vector<string> Alimento::getSmell() const {
    return smell;
}*/

string Alimento::getAlimentosAsString() const {
    ostringstream oss;

    oss << "\tAlimento: " << abreviation << endl
        << "\tId: " << id << endl
        << "\tPosicao: " << y << " " << x << endl;

    return oss.str();
}

int Alimento::getY() const {
    return y;
}

int Alimento::getX() const {
    return x;
}

Relva::Relva(char& abrv, int id, int y, int x): Alimento(abrv, id, y, x) { //r t p b a
    abrv = 'r';
    lifeTime = 20;
    nutValue = 3;
    toxicity = 0;
    smell.push_back("erva");
    smell.push_back("verdura");
}

Cenoura::Cenoura(char& abrv, int id, int y, int x): Alimento(abrv, id, y, x) {
    abrv = 't';
    nutValue = 4;
    toxicity = 0; //comeca em 0 e aumenta 1 ponto a cada instante;
    smell.push_back("verdura");
}

Corpo::Corpo(char& abrv, int id, int y, int x): Alimento(abrv, id, y, x) {
    abrv = 'p';
    lifeTime = 20;
    nutValue = 3;
    toxicity = 0;
    smell.push_back("carne");
}

Bife::Bife(char& abrv, int id, int y, int x): Alimento(abrv, id, y, x) {
    abrv = 'b';
    lifeTime = 30;
    nutValue = 10;
    toxicity = 2;
    smell.push_back("carne");
    smell.push_back("ketchup");
}

AlimentoM::AlimentoM(char& abrv, int id, int y, int x): Alimento(abrv, id, y, x) {
    //Golden Apple
    abrv = 'a';
    lifeTime = 10;
    nutValue = 50;
    toxicity = 0;
    smell.push_back("verdura");
}
//
// Created by João Carvalho on 07/11/2022.
//

#include <iostream>
#include <ncurses.h>
#include "Reserva.h"
#include "Simulador.h"
#include "Interface.h"

int main() {

    Terminal &t = Terminal::instance();

    Reserva* res = new Reserva();
    Simulador* sim = new Simulador(res);
    Interface* i = new Interface(sim, t);

    i->run();

    delete res;
    delete sim;
    delete i;

    return 0;
}
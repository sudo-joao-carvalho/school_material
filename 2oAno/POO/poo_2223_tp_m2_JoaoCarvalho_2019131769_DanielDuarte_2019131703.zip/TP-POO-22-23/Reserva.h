//
// Created by João Carvalho on 21/11/2022.
//

#ifndef TP_POO_22_23_RESERVA_H
#define TP_POO_22_23_RESERVA_H

#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <map>
#include "Animal.h"
#include "Alimento.h"

class Alimento;
class Animal;
class Reserva;
class Simulador;

class Reserva{
public:
    Reserva() {};
    Reserva(const Reserva& orig);
    ~Reserva();
    //Reserva& operator=(const Reserva& orig);

    void setNL(int nl);//tirar gets e sets e ser o simulador a dizer a reserva os tamanhos
    void setNC(int nc);

    int getNL() const;
    int getNC() const;

    //void criaAnimal(const char& abrv, int id);
    void criaAnimal(const char& abrv, int y, int x);
    void criaAlimento(const char& abrv, int y, int x);
    vector<Animal*> getAnimalVector() const;
    string getAnimalVectorAsString() const;
    vector<Alimento*> getAlimentoVector() const;
    string getAlimentosVectorAsString() const;

    void killAnimalByPosition(int l, int c);
    void killAnimalByID(int id);
    void killFoodByPosition(int l, int c);
    void killFoodByID(int id);
    void feedAnimalByPosition(int l, int c, int nutritionPoints, int toxicityPoints);
    void feedAnimalById(int id, int nutritionPoints, int toxicityPoints);

    int getSeconds() const;
    void setSeconds(int sec);

private:
    static int cnt;

    int NL;
    int NC;

    vector<Animal*> animais;
    vector<Alimento*> alimentos;

    int seconds;
};

#endif //TP_POO_22_23_RESERVA_H

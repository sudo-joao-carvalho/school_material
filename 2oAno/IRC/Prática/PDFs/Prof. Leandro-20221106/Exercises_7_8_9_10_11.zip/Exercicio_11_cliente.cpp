/*________________________________ cCasamenteiro.C ________________________________
O cliente, depois de enviar uma mensagem ao servidor, aguarda pela recepcao de um
endereco. Se o endereco recebido tiver sido enviado pelo servidor,
envia esse mesmo endereco ao seu par. Se o endereco recebido não tiver sido
enviado pelo servidor assume que e' o seu par quem o contacta dando por
concluido o "no'". Em ambas as situacoes os clientes reportam na stdout o endereco
da sua "cara-metade" e terminam.
___________________________________________________________________________________*/

#include <stdio.h>
#include <winsock.h>
#pragma comment(lib, "ws2_32.lib")

#define SERV_HOST_ADDR "127.0.0.1"
#define SERV_UDP_PORT  6000

void Abort(const char* msg);
/*________________________________ main ________________________________________
*/
int main(int argc, char* argv[]) {
	SOCKET sockfd;
	int iResult, msg_len, nbytes, tam_addr;
	struct sockaddr_in serv_addr, addr, cli1_addr;
	WSADATA wsaData;
	iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
	if (iResult != 0) {
		printf("WSAStartup failed: %d\n", iResult);
		getchar();
		exit(EXIT_FAILURE);
	}
	if (argc != 1) { /*Testa sintaxe*/
		fprintf(stderr, "Sintaxe: %s frase_a_enviar ip_destino_serv porto_destino_serv \n", argv[0]);
		exit(EXIT_FAILURE);
	}
	/*================ ABRE SOCKET PARA CONTACTAR O SERVIDOR ================*/
	if ((sockfd = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)) == INVALID_SOCKET)
		Abort("Impossibilidade de criar socket");
	/*================= PREENCHE ENDERECO DO SERVIDOR ====================*/
	memset((char*)&serv_addr, 0, sizeof(serv_addr));    /*a zero todos os bytes*/
	serv_addr.sin_family = AF_INET;              /*Address Family - Internet*/
	serv_addr.sin_addr.s_addr = inet_addr(SERV_HOST_ADDR);   /*IP => 32 bits*/
	serv_addr.sin_port = htons(SERV_UDP_PORT);          /* Porto well-known */
	/*====================== ENVIA MENSAGEM AO SERVIDOR ==================*/
	char mensagem[50];
	do {
		printf("Sua mensagem, por favor (digite ENTER para finalizar): ");
		fflush(stdout);
		if (fgets(mensagem, sizeof(mensagem), stdin) != 0) {
			if (strcmp(mensagem, "sair\n") == 0) break;
			msg_len = strlen(mensagem);
			if (sendto(sockfd, mensagem, msg_len, 0, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) == SOCKET_ERROR)
				Abort("SO nao conseguiu aceitar o datagram");
			printf("<CLI1> Mensagem enviada ao servidor.\n");
			tam_addr = sizeof(addr);
			nbytes = recvfrom(sockfd, (char*)&cli1_addr, sizeof(cli1_addr), 0, (struct sockaddr*)&addr, &tam_addr);
			if (nbytes == SOCKET_ERROR)
				Abort("Erro ao receber mensagem");
			if (nbytes != sizeof(cli1_addr))
				Abort("Mensagem recebida de tipo inesperado");
			if (strcmp(SERV_HOST_ADDR, inet_ntoa(addr.sin_addr)) == 0 && SERV_UDP_PORT == ntohs(addr.sin_port)) {//Mensagem enviada pelo servidor.
				//O Buffer contem uma estrutura do tipo struct sockaddr_in com o endereco IP e Porto do par remoto.O objectivo e' enviar esta informacao ao par remoto.
				nbytes = sendto(sockfd, (char*)&cli1_addr, nbytes, 0, (struct sockaddr*)&cli1_addr, sizeof(cli1_addr));
				if (nbytes == SOCKET_ERROR)
					Abort("Erro ao enviar endereco ao par remoto");
				printf("<CLI> Mensagem oriunda do servidor (sou o cliente 2)\n");
				printf("<CLI> Par remoto -> IP: %s; Porto: %d\n", inet_ntoa(cli1_addr.sin_addr), ntohs(cli1_addr.sin_port));
			}
			else {//Mensagem oriunda do meu par remoto
				printf("<CLI> Mensagem oriunda do par remoto (sou o cliente 1)\n");
				printf("<CLI> Par remoto -> IP: %s; Porto: %d\n", inet_ntoa(addr.sin_addr), ntohs(addr.sin_port));
			}
		}
		else {	break;
		}
	} while (1);
	/*========================== FECHA O SOCKET ============================*/
	closesocket(sockfd);
	exit(EXIT_SUCCESS);
}


/*________________________________ Abort________________________________________
Mostra a mensagem de erro associada ao ultimo erro no SO e abando com
"exit status" a 1
_______________________________________________________________________________
*/
void Abort(const char* msg) {
	fprintf(stderr, "\a<CLI1>Erro fatal: <%s> (codigo: %d)\n", msg, WSAGetLastError());
	exit(EXIT_FAILURE);
}


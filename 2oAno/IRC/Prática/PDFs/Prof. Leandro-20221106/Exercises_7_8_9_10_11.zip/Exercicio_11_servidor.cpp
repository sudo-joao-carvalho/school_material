/*_________________________________SCASAMENTEIRO.C___________________________________
O servidor serve de "casamenteiro" entre pares de clientes UDP. Ao
receber uma mensagem do primeiro cliente (o conteudo e' irrelevante),
anota o endereco deste (sockaddr_in) mas nao lhe responde. Quando
receber uma mensagem de um segundo cliente, remete a este ultimo o
endereco do primeiro, dando por concluida a sua tarefa.
____________________________________________________________________________________*/

#include <stdio.h>
#include <winsock.h>
#pragma comment(lib, "ws2_32.lib")
#define SERV_UDP_PORT 6000
#define BUFFERSIZE     4096
void Abort(const char* msg);
/*________________________________ main ________________________________________
*/
int main(int argc, char* argv[]) {
	SOCKET sockfd;
	int nbytes, iResult, size;
	struct sockaddr_in serv_addr, cli_addr1, cli_addr2;
	char buffer[BUFFERSIZE], addr;
	WSADATA wsaData;
	iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
	if (iResult != 0) {
		printf("WSAStartup failed: %d\n", iResult);
		getchar();
		exit(EXIT_FAILURE);
	}
	/*================ ABRE SOCKET PARA ESCUTA DE CLIENTES ==================*/
	if ((sockfd = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)) == INVALID_SOCKET)
		Abort("Impossibilidade de abrir socket");
	/*=================== PREENCHE ENDERECO DE ESCUTA =======================*/
	memset((char*)&serv_addr, 0, sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);  /*Recebe de qq interface*/
	serv_addr.sin_port = htons(SERV_UDP_PORT);  /*Escuta no porto Well-Known*/

	/*====================== REGISTA-SE PARA ESCUTA =========================*/
	if (bind(sockfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) == SOCKET_ERROR)
		Abort("Impossibilidade de registar-se para escuta");

	/*================ PASSA A ATENDER CLIENTES INTERACTIVAMENTE =============*/
	while (1) {
		fprintf(stderr, "<SER1> Esperando datagram...\n");
		size = sizeof(cli_addr1);
		nbytes = recvfrom(sockfd, buffer, sizeof(buffer), 0, (struct sockaddr*)&cli_addr1, &size);
		if (nbytes == SOCKET_ERROR)
			Abort("Erro na recepcao de datagrama (1)");
		else
			printf("\n<SER1> Cliente 1 registado\n");
		buffer[nbytes] = 0;
		printf("Msg recebida: %s\n", buffer);
		nbytes = recvfrom(sockfd, buffer, sizeof(buffer), 0, (struct sockaddr*)&cli_addr2, &size);
		if (nbytes == SOCKET_ERROR)
			Abort("Erro na recepcao de datagrama (2)");
		else
			printf("\n<SER1> Cliente 2 registado\n");
		buffer[nbytes] = 0;
		printf("Msg recebida: %s\n", buffer);
		nbytes = sendto(sockfd, (char*)&cli_addr1, sizeof(cli_addr1), 0, (struct sockaddr*)&cli_addr2, sizeof(cli_addr2));
		if (nbytes == SOCKET_ERROR)
			Abort("\n<SER1>Erro ao informar o cliente 2 da existencia do cliente 1\n");
		else
			printf("\n<SER1>Cliente 2 informado da existencia do cliente 1\n");
	}//while

}

/*________________________________ Abort________________________________________
Mostra a mensagem de erro associada ao ultimo erro nos Winsock e abandona com
"exit status" a 1
_______________________________________________________________________________
*/
void Abort(const char* msg) {
	fprintf(stderr, "\a<SER1> Erro fatal: <%s> (codigo: %d)\n", msg, WSAGetLastError());
	exit(EXIT_FAILURE);
}


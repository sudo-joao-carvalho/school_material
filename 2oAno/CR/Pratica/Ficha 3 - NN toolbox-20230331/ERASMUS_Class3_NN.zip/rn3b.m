function rn3b()
%Use the nntool to create, train and simulate a feedforward neural net

% clear
clear all;
close all;

% initialize inputs
p = [0 0 1 1; 0 1 0 1];

%which gate?
fprintf('Choose the logic gate:\n');
fprintf('1 - AND\n');
fprintf('2 - OR\n');
fprintf('3 - NAND\n');
fprintf('4 - XOR\n');
tmp =  input('                        operador? (default 1) = ');

% initialize targets
if isempty(tmp)
    t = [0 0 0 1];
    op='AND';
else
    switch tmp
        case 1
            t = [0 0 0 1];
            op='AND';
        case 2
            t = % COMPLETE:
            op='OR';
        case 3
            t = % COMPLETE:
            op='NAND';
        case 4
            t = % COMPLETE:
            op='XOR';
        otherwise
            t = [0 0 0 1];
            op='AND';
    end
end


% COMPLETE: create a feedforward NN called net


% COMPLETAR: Initialize the following parameters
%%%%% Activation Function for the output layer


%%%%% Training function 


%%%%% Number of ephocs

% Use all the exaples for training
net.divideFcn = '';                 

% COMPLETE: train the NN


% Visualize the NN
view(net)

% % COMPLETE: use the nntool to simulate the NN (store the output in y)


% Show output
y = (y >= 0.5);
fprintf('Outpt of the NN for %s:', op);
disp(y);
fprintf('Desired target for %s:', op);
disp(t);

end

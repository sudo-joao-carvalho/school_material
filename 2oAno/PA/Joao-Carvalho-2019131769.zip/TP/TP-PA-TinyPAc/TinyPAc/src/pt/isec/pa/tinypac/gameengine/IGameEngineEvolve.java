package pt.isec.pa.tinypac.gameengine;

public interface IGameEngineEvolve {
    void evolve(IGameEngine gameEngine, long currentTime);
}
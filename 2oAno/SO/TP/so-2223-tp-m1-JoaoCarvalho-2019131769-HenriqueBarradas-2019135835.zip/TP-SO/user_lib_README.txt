1) Identificar a versão correta do ficheiro binário (".o") à arquitetura
   usada no projeto (linux intel x64 / Apple/Intel / Apple/M1)
  -> Outra arquitetura? falar com o docente na primeira aula a que for

2) Mudar onome do binário escolhido no ponto anterior para users_lib.o
   (ou seja, apagar os parentesis e o que lá está dentro)

3) Incluir o .h e o binário no projeto

4) Ver o .h para obter mais informações acerca das funções da biblioteca

O ficheiro .c da biblioteca não faz parte do material disponibilizado

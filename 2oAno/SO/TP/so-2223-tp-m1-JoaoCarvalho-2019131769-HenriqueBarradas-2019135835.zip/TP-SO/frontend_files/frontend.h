#ifndef FRONTEND_H
#define FRONTEND_H

char* readCommands(char* commandM);
void commandHelp();

#endif
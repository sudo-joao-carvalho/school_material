#ifndef FRONTEND_H
#define FRONTEND_H

//void readCommands(char* commandM, Clientes aux);
void commandHelp();

#endif
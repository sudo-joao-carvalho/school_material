package pt.isec.ans.teoweather

import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import pt.isec.ans.teoweather.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    companion object {
        private const val TAG = "MainActivity"
    }

    private val viewModel : WeatherViewModel by viewModels()
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel.location.observe(this) {
            binding.tvCity.text = it
        }

        viewModel.currentTemp.observe(this) {
            binding.tvTemp.text = "$it"
        }

        viewModel.icon.observe(this) {
            Glide.with(this)
                .load(it)
                .into(binding.iconWeather)
        }

        viewModel.webContent.observe(this) {
            binding.tvContent.text = it
        }


        binding.btnRefresh.setOnClickListener {
            viewModel.getContent()
        }

        val netState1 = NetUtils.verifyNetworkState(this)
        val netState2 = NetUtils.verifyNetworkStateV2(this)
        val netState3 = NetUtils.verifyNetworkStateV3(this)

        Log.i(TAG,"ns1 = $netState1; ns2 = $netState2; ns3 = $netState3;")
        if (!netState1 && !netState2 && !netState3)
            finish()
    }
}
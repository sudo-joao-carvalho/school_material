package pt.isec.ans.teoweather

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import org.json.JSONObject

class WeatherViewModel : ViewModel() {
    companion object {
        private const val TAG = "ViewModel"
        private const val API_KEY = "95fc0d46b3914352a5c214419221611"
        private const val CITY = "Coimbra"
        private const val URL = "https://api.weatherapi.com/v1/forecast.json?" +
                "key=$API_KEY&q=$CITY&days=2&aqi=no&alerts=no\n"
    }

    private val _webContent = MutableLiveData<String?>(null)
    val webContent : LiveData<String?>
        get()=_webContent

    private val _location = MutableLiveData<String?>(null)
    val location : LiveData<String?>
        get() = _location

    private val _icon = MutableLiveData<String?>(null)
    val icon : LiveData<String?>
        get() = _icon

    private val _currentTemp = MutableLiveData<Double>(0.0)
    val currentTemp : LiveData<Double>
        get() = _currentTemp

    fun getContent() {
        viewModelScope.launch {
            NetUtils.getDataAsync(URL) { result ->
                result ?: return@getDataAsync

                _webContent.postValue(result)

                try {
                    val json = JSONObject(result)
                    _webContent.postValue(json.toString(4))
                    val jLocation = json.getJSONObject("location")
                    val jCurrent = json.getJSONObject("current")
                    val dTemp = jCurrent.getDouble("temp_c")
                    val jCondition = jCurrent.getJSONObject("condition")
                    val icon = jCondition.getString("icon")
                    _location.postValue(jLocation.getString("name"))
                    _currentTemp.postValue(dTemp)
                    _icon.postValue("https:$icon")
                } catch ( _ : Exception) {}
            }
        }
    }
}



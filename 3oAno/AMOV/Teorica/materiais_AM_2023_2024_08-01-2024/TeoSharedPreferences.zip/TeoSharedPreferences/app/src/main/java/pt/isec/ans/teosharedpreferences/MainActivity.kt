package pt.isec.ans.teosharedpreferences

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import androidx.activity.result.contract.ActivityResultContracts
import androidx.preference.PreferenceManager
import org.json.JSONArray
import org.json.JSONObject
import pt.isec.ans.teosharedpreferences.databinding.ActivityMainBinding
import kotlin.math.log

const val SHAREDPREFS = "MySharedPreferences"

class MainActivity : AppCompatActivity() {
    lateinit var binding : ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        with(binding) {
            tvpMinus.setOnClickListener { updatePrefs(-1) }
            tvpPlus.setOnClickListener{ updatePrefs(1) }
            tvspMinus.setOnClickListener { updateSharedPrefs(-1) }
            tvspPlus.setOnClickListener{ updateSharedPrefs(1) }
        }
    }

    override fun onResume() {
        super.onResume()
        updatePrefs(0)
        updateSharedPrefs(0)
    }

    fun updatePrefs(param : Int) {
        val prefs = getPreferences(MODE_PRIVATE)
        val value = prefs.getInt("value",0) + param
        with(prefs.edit()) {
            putInt("value",value)
            apply()
        }
        binding.tvpValue.text = value.toString()
    }
    fun updateSharedPrefs(param : Int) {
        val sharedPrefs = getSharedPreferences(SHAREDPREFS,MODE_PRIVATE)
        val value = sharedPrefs.getInt("value",0) + param
        with(sharedPrefs.edit()) {
            putInt("value",value)
            apply()
        }
        binding.tvspValue.text = value.toString()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_prefs,menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.menuNext -> {
                startActivity(Intent(this,SecondActivity::class.java))
                return true
            }
            R.id.menuSettings -> {
                settingsActivityResult.launch(
                    Intent(this,SettingsActivity::class.java)
                )
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    val settingsActivityResult = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
            val sharedPrefs = PreferenceManager.getDefaultSharedPreferences(this)
            for( (k,v) in sharedPrefs.all)
                Log.i("Settings", "$k = $v")

            /*sharedPrefs.all.forEach {
                val (k,v) = it
                    ...
            }*/
    }


}


package pt.isec.ans.teosharedpreferences

import android.content.pm.PackageManager.PERMISSION_GRANTED
import android.os.Bundle
import android.util.Log
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.preference.PreferenceFragmentCompat
import java.util.jar.Manifest
import kotlin.math.log

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.settings_activity)
        if (savedInstanceState == null) {
            Log.i("TAG", "onCreate: savedInstanceState == null")
            supportFragmentManager
                .beginTransaction()
                .replace(R.id.settings, SettingsFragment())
                .commit()
        }
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        // O código seguinte é para dar suporte ao setting que permite
        // fazer uma chamada telefónica
        if (ContextCompat.checkSelfPermission(this,android.Manifest.permission.CALL_PHONE)!=PERMISSION_GRANTED)
            registerForActivityResult(ActivityResultContracts.RequestPermission()) { result ->
                if (!result)
                    finish()
            }.launch(android.Manifest.permission.CALL_PHONE)
    }

    class SettingsFragment : PreferenceFragmentCompat() {
        override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
            setPreferencesFromResource(R.xml.root_preferences, rootKey)
        }
    }
}
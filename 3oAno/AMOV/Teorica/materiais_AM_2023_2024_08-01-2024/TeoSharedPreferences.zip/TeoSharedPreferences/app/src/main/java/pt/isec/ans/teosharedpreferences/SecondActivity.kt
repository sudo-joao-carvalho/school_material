package pt.isec.ans.teosharedpreferences

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import pt.isec.ans.teosharedpreferences.databinding.ActivitySecondBinding

class SecondActivity : AppCompatActivity() {
    lateinit var binding : ActivitySecondBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySecondBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        with(binding) {
            tvpMinus.setOnClickListener { updatePrefs(-1) }
            tvpPlus.setOnClickListener{ updatePrefs(1) }
            tvspMinus.setOnClickListener { updateSharedPrefs(-1) }
            tvspPlus.setOnClickListener{ updateSharedPrefs(1) }
        }

        updatePrefs(0)
        updateSharedPrefs(0)
    }
    fun updatePrefs(param : Int) {
        val prefs = getPreferences(MODE_PRIVATE)
        val value = prefs.getInt("value",0) + param
        with(prefs.edit()) {
            putInt("value",value)
            apply()
        }
        binding.tvpValue.text = value.toString()
    }
    fun updateSharedPrefs(param : Int) {
        val sharedPrefs = getSharedPreferences(SHAREDPREFS,MODE_PRIVATE)
        val value = sharedPrefs.getInt("value",0) + param
        with(sharedPrefs.edit()) {
            putInt("value",value)
            apply()
        }
        binding.tvspValue.text = value.toString()
    }
}
package pt.isec.ans.teobackgroundtasks

import android.app.IntentService
import android.content.Intent
import android.content.Context

// deprecated => JobIntentService... deprecated => WorkManager
class MyIntentService : IntentService("MyIntentService") {

    override fun onHandleIntent(intent: Intent?) {
        Utils.execute("MyIntentService")
    }

}
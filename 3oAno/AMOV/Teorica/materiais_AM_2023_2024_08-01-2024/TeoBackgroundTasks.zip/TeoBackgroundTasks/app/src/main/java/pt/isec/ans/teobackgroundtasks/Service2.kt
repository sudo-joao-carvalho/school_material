package pt.isec.ans.teobackgroundtasks

import android.app.*
import android.content.Intent
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.edit
import kotlin.concurrent.thread

class Service2 : Service() {
    companion object {
        private const val TAG = "Service 2"

        private const val SHAREDPREFS_NAME = "Service2"
        const val BACKGROUND_PARAM = "background"
        const val STICKY_PARAM = "sticky"
    }

    var workThread : Thread? = null
    private var mNM: NotificationManager? = null
    private val NOTIFICATION: Int = 1234
    val channel_id = "Service2ch"
    val channel_name = "Service 2 Channel"
    val channel_importance =    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N)
                                    NotificationManager.IMPORTANCE_DEFAULT
                                else
                                    0


    fun work(title: String, nrIters: Int = 20) {
        repeat(nrIters) {
            val str = "$title: ${it}"
            Log.i(TAG, str)

            try {
                Thread.sleep(1000)
            } catch (_: Exception) {
                Log.i(TAG, "work: forced ending...")
            } finally {
                if (workThread == null)
                    return
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        Log.i(TAG, "onCreate: ")
        mNM = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            val channel= NotificationChannel(channel_id,channel_name,channel_importance)
            mNM?.createNotificationChannel(channel)
        }

        // Display a notification about us starting.  We put an icon in the status bar.
        showNotification();
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val ret = super.onStartCommand(intent, flags, startId)
        Log.i(TAG, "onStartCommand: 0")
        val sp = getSharedPreferences(SHAREDPREFS_NAME, MODE_PRIVATE)
        val baseBack = sp.getBoolean(BACKGROUND_PARAM, true)
        val baseSticky = sp.getBoolean(STICKY_PARAM, true)
        val background = intent?.getBooleanExtra(BACKGROUND_PARAM, false) ?: baseBack
        val stickyFlag = intent?.getBooleanExtra(STICKY_PARAM, false) ?: baseSticky
        sp.edit {
            putBoolean(BACKGROUND_PARAM, background)
            putBoolean(STICKY_PARAM, stickyFlag)
            apply()
        }
        Log.i(
            TAG, "onStartCommand: 1" +
                    "Intent? ${intent != null}  " +
                    "Background? $background  " +
                    "Sticky? $stickyFlag"
        )
        if (!background)
            work(TAG + "A")
        else
            workThread = thread {
                work(TAG + "B", 50)
            }
        Log.i(TAG, "onStartCommand: 2")
        return if (stickyFlag) START_STICKY else START_NOT_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.i(TAG, "onDestroy: ")
        val temp = workThread
        workThread = null
        temp?.interrupt()
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            //stopForeground(true) - deprecated
            stopForeground(STOP_FOREGROUND_REMOVE)
        }
    }

    override fun onBind(intent: Intent): IBinder {
        Log.i(TAG, "onBind: ")
        TODO("Return the communication channel to the service.")
    }

    private fun showNotification() {
        // In this sample, we'll use the same text for the ticker and the expanded notification
        val text = "Service Running..."

        // The PendingIntent to launch our activity if the user selects this notification
        val contentIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )

        // Set the info for the views that show in the notification panel.
        val notification: Notification = NotificationCompat.Builder(this,channel_id)
            .setSmallIcon(android.R.drawable.btn_star) // the status icon
            .setTicker(text) // the status text
            .setWhen(System.currentTimeMillis()) // the time stamp
            .setContentTitle("Service 2") // the label of the entry
            .setContentText(text) // the contents of the entry
            .setContentIntent(contentIntent) // The intent to send when the entry is clicked
            .build()

        // Send the notification.
        if (mNM==null)
            Log.i(TAG, "showNotification: null")
        else
            Log.i(TAG, "showNotification: ok")
        //mNM?.notify(NOTIFICATION, notification)
        startForeground(NOTIFICATION,notification)
    }

}
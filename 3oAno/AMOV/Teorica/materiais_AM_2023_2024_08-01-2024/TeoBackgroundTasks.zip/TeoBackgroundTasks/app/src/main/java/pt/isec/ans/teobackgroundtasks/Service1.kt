package pt.isec.ans.teobackgroundtasks

import android.R
import android.app.*
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.edit
import kotlin.concurrent.thread


class Service1 : Service() {
    companion object {
        private const val TAG = "Service 1"

        private const val SHAREDPREFS_NAME = "Service1"
        const val BACKGROUND_PARAM = "background"
        const val STICKY_PARAM = "sticky"
    }

    var workThread : Thread? = null
    var baseValue = 0

    fun work(title: String, nrIters: Int = 20) {
        repeat(nrIters) {
            val str = "$title: ${baseValue+it}"
            Log.i(TAG, str)

            try {
                Thread.sleep(1000)
            } catch (_: Exception) {
                Log.i(TAG, "work: forced ending...")   
            } finally {
                if (workThread == null)
                    return
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        Log.i(TAG, "onCreate: ")
    }

    /*
    VERSION 1
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val ret = super.onStartCommand(intent, flags, startId)
        Log.i(TAG, "onStartCommand: 0")
        work(TAG)
        Log.i(TAG, "onStartCommand: 2")
        return ret
    }
     */

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val ret = super.onStartCommand(intent, flags, startId)
        Log.i(TAG, "onStartCommand: 0")
        val sp = getSharedPreferences(SHAREDPREFS_NAME, MODE_PRIVATE)
        val baseBack = sp.getBoolean(BACKGROUND_PARAM, true)
        val baseSticky = sp.getBoolean(STICKY_PARAM, true)
        val background = intent?.getBooleanExtra(BACKGROUND_PARAM, false) ?: baseBack
        val stickyFlag = intent?.getBooleanExtra(STICKY_PARAM, false) ?: baseSticky
        sp.edit {
            putBoolean(BACKGROUND_PARAM, background)
            putBoolean(STICKY_PARAM, stickyFlag)
            apply()
        }
        Log.i(
            TAG, "onStartCommand: 1" +
                    "Intent? ${intent != null}  " +
                    "Background? $background  " +
                    "Sticky? $stickyFlag"
        )
        if (!background)
            work(TAG + "A")
        else
            workThread = thread {
                work(TAG + "B", 50)
            }
        Log.i(TAG, "onStartCommand: 2")
        return if (stickyFlag)  (START_STICKY /*START_REDELIVER_INTENT*/) else START_NOT_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.i(TAG, "onDestroy: ")
        val temp = workThread
        workThread = null
        temp?.interrupt()
    }

    inner class MyBinder : Binder() {
        fun setNewBase(base : Int) {
            baseValue = base
        }
        fun getService() : Service1 = this@Service1
    }
    override fun onBind(intent: Intent): IBinder {
        Log.i(TAG, "onBind: ")
        if (workThread==null) {
            workThread = thread {
                work(TAG + "C", 50)
            }
        }
        return MyBinder()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        Log.i(TAG, "onUnbind: ")
        return super.onUnbind(intent) // return true to call onRebind next time
    }

    override fun onRebind(intent: Intent?) {
        super.onRebind(intent)
        Log.i(TAG, "onRebind: ")
    }

}
package pt.isec.ans.teobackgroundtasks

import android.app.Activity
import android.os.Handler
import android.util.Log
import android.widget.TextView


class Utils {
    companion object {
        private const val TAG = "Utils"

        private var count = 0

        fun execute_v0(
            title: String,
            nrIters: Int = 20,
            tv: TextView? = null,
            millis: Long = 1000
        ) {
            var id = ++count
            repeat(nrIters) {
                val str = "$title [$id]: ${it} ${Thread.currentThread().id}"
                Log.i(TAG, str)
                tv?.apply {
                    text = str + "\n" + text
                }
                Thread.sleep(millis)
            }
        }

        fun execute(title: String, nrIters: Int = 20, tv: TextView? = null, millis: Long = 1000) {
            var id = ++count
            //var x = Handler()
            //x.post...
            repeat(nrIters) {
                val str = "$title [$id]: ${it} ${Thread.currentThread().id}"
                Log.i(TAG, str)
                tv?.post { //alternative: Activity.runOnUiThread { ... }
                    tv.text = str + "\n" + tv.text
                }
                Thread.sleep(millis)
            }
        }
    }
}
package pt.isec.ans.teobackgroundtasks

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.DownloadManager
import android.app.PendingIntent
import android.app.job.JobInfo
import android.app.job.JobScheduler
import android.content.*
import android.net.Uri
import android.os.AsyncTask
import android.os.Bundle
import android.os.IBinder
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.JobIntentService
import androidx.work.*
import kotlinx.coroutines.*
import java.lang.Runnable
import java.util.*
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread
import kotlin.random.Random




class MainActivity : AppCompatActivity() {
    companion object {
        private const val TAG = "MainActivity::Button"
    }

    val buttons = mapOf(
        "No threads" to ::onNoThreads,
        "Thread with error" to ::onThreadWithError,
        "Thread 1" to ::onThread1,
        "Thread 2" to ::onThread2,
        "Thread 3" to ::onThread3,
        "Thread 4" to ::onThread4,
        "Thread Pool" to ::onThreadPool,
        "Executor 1" to ::onExecutor1,
        "Executor 2" to ::onExecutor2,
        "Executor 3" to ::onExecutor3,
        "Async Task" to ::onAsyncTask,
        "Coroutines" to ::onCoroutines,
        "Alarm Manager" to ::onAlarmManager,
        "Download Manager" to ::onDownloadManager,
        "Work Manager" to ::onWorkManager,
        "Job Scheduler" to ::onJobScheduler,
        "Start Service 1a" to ::onStartService1A,
        "Start Service 1b" to ::onStartService1B,
        "Start Service 1c" to ::onStartService1C,
        "Start Service 2" to ::onStartService2,
        "Stop Service 1" to ::onStopService1,
        "Stop Service 2" to ::onStopService2,
        "Bind Service 1" to ::onBindService,
        "Unbind Service 1" to ::onUnbindService,
        "Intent Service" to ::onIntentService,
        "Job Intent Service" to ::onJobIntentService
    )
    lateinit var tvLog: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val ll = findViewById<LinearLayout>(R.id.llButtons)
        tvLog = findViewById(R.id.tvLog)
        tvLog.setOnLongClickListener {
            tvLog.text = ""
            true
        }
        for ((k, v) in buttons) {
            ll.addView(Button(this).apply {
                text = k
                isAllCaps = false
                setOnClickListener(v)
                textSize = 20f
            })
        }
    }

    fun onNoThreads(v: View) {
        Log.i(TAG, "onNoThreads: 0")
        Utils.execute_v0("onNoThreads", tv = tvLog, millis = 500)
        Log.i(TAG, "onNoThreads: 9")
    }

    fun onThreadWithError(v: View) {
        Log.i(TAG, "onThreadWithError: 0")
        var r: Runnable = Runnable {
            Utils.execute_v0("onThreadWithError", tv = tvLog, millis = 500)
        }
        var t = Thread(r)
        Toast.makeText(this, "The application should crash", Toast.LENGTH_LONG).show()
        t.start()
        Log.i(TAG, "onThreadWithError: 9")
    }

    fun onThread1(v: View) {
        Log.i(TAG, "onThread1: 0")
        var r: Runnable = Runnable {
            Utils.execute("onThread1", tv = tvLog, millis = 500)
        }
        var t = Thread(r)
        t.start()
        Log.i(TAG, "onThread1: 9")
    }

    /* class MyThread : Thread() {
        override fun run() {
            super.run()
            //TODO
        }
    }*/
    fun onThread2(v: View) {
        Log.i(TAG, "onThread2: 0")
        var t = Thread {
            Utils.execute("onThread2", tv = tvLog, millis = 500)
        }
        t.start()
        Log.i(TAG, "onThread2: 9")
    }

    fun onThread3(v: View) {
        Log.i(TAG, "onThread3: 0")
        thread {
            Utils.execute("onThread3", tv = tvLog, millis = 500)
        }
        Log.i(TAG, "onThread3: 9")
    }

    fun onThread4(v: View) {
        Log.i(TAG, "onThread4: 0")
        repeat(5) {
            thread {
                Utils.execute("onThread4.${it + 1}", tv = tvLog, millis = 500)
            }
        }
        Log.i(TAG, "onThread4: 9")
    }

    //Can be defined in the application object
    val PROCESSOR_CORES = Runtime.getRuntime().availableProcessors()
    val threadPoolExecutor = ThreadPoolExecutor(
        PROCESSOR_CORES, PROCESSOR_CORES,
        1, TimeUnit.SECONDS, LinkedBlockingQueue<Runnable>()
    )

    fun onThreadPool(v: View) {
        Log.i(TAG, "onThreadPool: 0 #$PROCESSOR_CORES")
        repeat(5) {
            threadPoolExecutor.execute {
                Utils.execute("onThreadPool.${it + 1}", tv = tvLog, millis = 500)
            }
        }
        Log.i(TAG, "onThreadPool: 9")
    }

    val executor1 = Executors.newSingleThreadExecutor()
    val executor2 = Executors.newFixedThreadPool(PROCESSOR_CORES)
    val executor3 = Executors.newScheduledThreadPool(PROCESSOR_CORES)

    fun onExecutor1(v: View) {
        Log.i(TAG, "onExecutor1: 0")
        repeat(5) {
            executor1.execute {
                Utils.execute("onExecutor1.${it + 1}", tv = tvLog, millis = 500)
            }
        }
        Log.i(TAG, "onExecutor1: 9")
    }

    fun onExecutor2(v: View) {
        Log.i(TAG, "onExecutor2: 0")
        repeat(5) {
            executor2.execute {
                Utils.execute("onExecutor2.${it + 1}", tv = tvLog, millis = 500)
            }
        }
        Log.i(TAG, "onExecutor2: 9")
    }

    fun onExecutor3(v: View) {
        Log.i(TAG, "onExecutor3: 0")
        repeat(5) {
            executor3.schedule(
                { Utils.execute("onExecutor3a.${it + 1}", tv = tvLog, millis = 500) },
                5L + it, TimeUnit.SECONDS
            )
        }
        /*executor3.scheduleAtFixedRate(
            { Utils.execute("onExecutor3b",tv = tvLog, millis = 100) },
            10L, 5L, TimeUnit.SECONDS
        )
        executor3.scheduleWithFixedDelay(
            { Utils.execute("onExecutor3c",tv = tvLog, millis = 100) },
            10L, 5L, TimeUnit.SECONDS
        )*/

        Log.i(TAG, "onExecutor3: 9")
    }

    @Suppress("DEPRECATION")
    fun onAsyncTask(v: View) {
        Log.i(TAG, "onAsyncTask: 0")
        val asyncTask = MyAsyncTask(tvLog)
        Log.i(TAG, "onAsyncTask: 1")
        asyncTask.execute("ABC", "DEFG", "HIJKL", "MNOPQR")
        Log.i(TAG, "onAsyncTask: 2")
    }

    @Suppress("DEPRECATION")
    class MyAsyncTask(val tv: TextView) : AsyncTask<String, Int, Boolean>() {
        override fun onPreExecute() {
            super.onPreExecute()
            Log.i(TAG, "onPreExecute: ${Thread.currentThread().id}")
            tv.text = "PreExecute\n" + tv.text
        }

        override fun doInBackground(vararg params: String?): Boolean {
            Log.i(TAG, "doInBackground: ini ${Thread.currentThread().id}")
            repeat(20) {
                Log.i(TAG, "doInBackground: $it   ${Thread.currentThread().id}")
                publishProgress(it, params[it % params.size]?.length)
                Thread.sleep(500)
            }
            Log.i(TAG, "doInBackground: end")
            return true
        }

        override fun onProgressUpdate(vararg values: Int?) {
            super.onProgressUpdate(*values)
            val str = "Value[${values[0]}]: ${values[1]}"
            Log.i(TAG, "onProgressUpdate: $str   ${Thread.currentThread().id}")
            tv.text = str + "\n" + tv.text
        }

        override fun onPostExecute(result: Boolean?) {
            super.onPostExecute(result)
            Log.i(TAG, "onPostExecute: $result   ${Thread.currentThread().id}")
            tv.text = "PostExecute: $result\n" + tv.text
        }
    }

    fun onCoroutines(v: View) {
        Log.i(TAG, "onCoroutines: 0 ${Thread.currentThread().id}")

        CoroutineScope(Dispatchers.IO).async {
            Log.i(TAG, "onCoroutines: 1 ${Thread.currentThread().id}")
            Utils.execute("onCoroutines", 5, tvLog, 500)
            Log.i(TAG, "onCoroutines: 2 ${Thread.currentThread().id}")
            launch { procCoroutinesA("A") }
            Log.i(TAG, "onCoroutines: 3 ${Thread.currentThread().id}")
            launch { procCoroutinesB("B") }
            Log.i(TAG, "onCoroutines: 4 ${Thread.currentThread().id}")
            val x = async { procCoroutinesA("C") }
            Log.i(TAG, "onCoroutines: 5 ${Thread.currentThread().id}")
            val y = async { procCoroutinesB("D") }

            Log.i(
                TAG, "onCoroutines: 6 ${Thread.currentThread().id}" +
                        "   => ${x.await()} ${y.await()}"
            )
            Log.i(TAG, "onCoroutines: 7 ${Thread.currentThread().id}")
        }
        tvLog.text = "onCoroutines"
        Log.i(TAG, "onCoroutines: 9 ${Thread.currentThread().id}")
    }

    suspend fun procCoroutinesA(s: String): Long {
        repeat(5) {
            delay(750)
            //Thread.sleep(750)
            Log.i(TAG, "procCoroutinesA $s: $it ${Thread.currentThread().id}")
            CoroutineScope(Dispatchers.Main).async {
                tvLog.text = "procCoroutinesA $s: $it\n" + tvLog.text
            }
        }
        return Thread.currentThread().id
    }

    suspend fun procCoroutinesB(s: String): Long {
        repeat(5) {
            delay(500)
            //Thread.sleep(500)
            Log.i(TAG, "procCoroutinesB $s: $it ${Thread.currentThread().id}")
            CoroutineScope(Dispatchers.Main).launch {
                tvLog.text = "procCoroutinesB $s: $it\n" + tvLog.text
            }
        }
        return Thread.currentThread().id
    }

    @SuppressLint("ScheduleExactAlarm")
    fun onAlarmManager(v: View) {
        Log.i(TAG, "onAlarmManager: 0")
        val mapIntent = Intent(Intent.ACTION_VIEW)
        mapIntent.data = Uri.parse("https://maps.google.com/maps?q=loc:40.1926,-8.4116")
        //mapIntent.setPackage("com.google.android.apps.maps")
        val alarmMgr = getSystemService(ALARM_SERVICE) as AlarmManager
        val now = Date().time
        val schedule = now + 5000
        Log.i(TAG, "onAlarmManager: 5  $now  $schedule")
        alarmMgr.setExact(
            AlarmManager.RTC,
            schedule,
            PendingIntent.getActivity(this, 1234, mapIntent, PendingIntent.FLAG_MUTABLE)
        )
        Log.i(TAG, "onAlarmManager: 9")
    }

    @SuppressLint("UnspecifiedRegisterReceiverFlag")
    fun onDownloadManager(v: View) {
        Log.i(TAG, "onDownloadManager: 0")
        val request = DownloadManager.Request(Uri.parse("https://upload.wikimedia.org/wikipedia/commons/5/50/ISEC.png")).apply {
            setTitle("Downloading [AMOV]")
            setDescription("Downloading example")
            //setRequiresCharging(true)
            setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            setDestinationInExternalFilesDir(
                this@MainActivity,
                "websites", "isec.png"
            )
        }
        Log.i(TAG, "onDownloadManager: 1")
        registerReceiver(object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                val id = intent?.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID,-1)
                Log.i(TAG, "onDownloadManager: BR $id")
                Toast.makeText(this@MainActivity, "Download completed", Toast.LENGTH_LONG).show()
                unregisterReceiver(this)
            }
        }, IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE))

        val downloadManager = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
        Log.i(TAG, "onDownloadManager: 5")
        val id = downloadManager.enqueue(request)
        Log.i(TAG, "onDownloadManager: 9 [$id]")
    }

    fun onWorkManager(v: View) {
        Log.i(TAG, "onWorkManager: 0")
        //val otwr = OneTimeWorkRequest.from(MyWorker::class.java)
        val constraints = Constraints.Builder()
            .setRequiresCharging(true)
            .setRequiredNetworkType(NetworkType.NOT_ROAMING)
            .build()
        val otwr = OneTimeWorkRequest.Builder(MyWorker::class.java)
            .setInitialDelay(5, TimeUnit.SECONDS)
            .setConstraints(constraints)
            .build()

        //val pwr = PeriodicWorkRequest.Builder(MyWorker::class.java,15,TimeUnit.MINUTES)
        WorkManager.getInstance(this).apply {
            enqueue(otwr)
            getWorkInfoByIdLiveData(otwr.id).observe(this@MainActivity) {
                Log.i(TAG, "onWorkManager: onLiveData ${it.state} Finished: ${it.state.isFinished}")
                if (it.state.isFinished)
                    Toast.makeText(this@MainActivity, "Work done", Toast.LENGTH_LONG).show()
            }
        }
        Log.i(TAG, "onWorkManager: 9")
    }

    class MyWorker(context: Context, workerParams: WorkerParameters) :
        Worker(context, workerParams) {
        override fun doWork(): Result {
            Utils.execute("MyWorker", 20, millis = 500)
            return Result.success()
        }
    }

    fun onJobScheduler(v: View) {
        Log.i(TAG, "onJobScheduler: 0")
        val jobScheduler = getSystemService(JOB_SCHEDULER_SERVICE) as JobScheduler

        val cn = ComponentName(this, MyJobService::class.java)

        val jobInfo = JobInfo.Builder(1234, cn)
            .setRequiresCharging(true)
            //.setPeriodic(3600000)
            //.setPersisted(true) // reiniciar depois de reboot.
            //necessita de permissão: RECEIVE_BOOT_COMPLETED
            .build()

        jobScheduler.schedule(jobInfo)
        Log.i(TAG, "onJobScheduler: 9")
    }

    fun onStartService1A(v: View) {
        Log.i(TAG, "onStartService1A: ")
        val intent = Intent(this, Service1::class.java)
        startService(intent)
    }

    fun onStartService1B(v: View) {
        Log.i(TAG, "onStartService1B: ")
        val intent = Intent(this, Service1::class.java)
        intent.putExtra(Service1.BACKGROUND_PARAM, true)
        startService(intent)
    }

    fun onStartService1C(v: View) {
        Log.i(TAG, "onStartService1C: ")
        val intent = Intent(this, Service1::class.java)
        intent.putExtra(Service1.BACKGROUND_PARAM, true)
        intent.putExtra(Service1.STICKY_PARAM, true)
        startService(intent)
    }

    fun onStartService2(v: View) {
        Log.i(TAG, "onStartService2: 0")
        val intent = Intent(this, Service2::class.java)
        intent.putExtra(Service2.BACKGROUND_PARAM, true)
        intent.putExtra(Service2.STICKY_PARAM, true)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            Log.i(TAG, "onStartService2: a")
            startForegroundService(intent)
        } else {
            Log.i(TAG, "onStartService2: b")
            startService(intent)
        }
        Log.i(TAG, "onStartServiceD: c")
    }


    fun onStopService1(v: View) {
        Log.i(TAG, "onStopService1: ")
        val intent = Intent(this, Service1::class.java)
        stopService(intent)
    }

    fun onStopService2(v: View) {
        Log.i(TAG, "onStopService2: ")
        val intent = Intent(this, Service2::class.java)
        stopService(intent)
    }

    val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val sc = service as Service1.MyBinder
            sc.setNewBase(Random.nextInt(1, 10) * 1000)
        }

        override fun onServiceDisconnected(name: ComponentName?) {

        }

    }
    fun onBindService(v: View) {
        val intent = Intent(this, Service1::class.java)
        bindService(intent, serviceConnection, BIND_AUTO_CREATE)
    }

    fun onUnbindService(v: View) {
        try {
            unbindService(serviceConnection)
        } catch (_: Exception) {
            Log.i(TAG, "onUnbindService: Error")
        }
    }

    fun onIntentService(v: View) {
        val intent = Intent(this, MyIntentService::class.java)
        startService(intent)
    }

    fun onJobIntentService(v: View) {
        val intent = Intent(this, MyJobIntentService::class.java) //  pass data in Extras
        JobIntentService.enqueueWork(this, MyJobIntentService::class.java, 1234, intent)
    }

}


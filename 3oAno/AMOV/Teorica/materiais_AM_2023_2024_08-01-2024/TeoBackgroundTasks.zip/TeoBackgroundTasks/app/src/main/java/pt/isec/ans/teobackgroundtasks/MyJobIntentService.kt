package pt.isec.ans.teobackgroundtasks

import android.content.Intent
import androidx.core.app.JobIntentService

//deprecated => WorkManager
class MyJobIntentService : JobIntentService() {

    override fun onHandleWork(intent: Intent) {
        Utils.execute("MyJobIntentService")
    }
}
package pt.isec.ans.tst20221109

import android.database.Cursor
import android.icu.lang.UCharacter.GraphemeClusterBreak.T
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.loader.app.LoaderManager
import androidx.loader.app.LoaderManager.LoaderCallbacks
import androidx.loader.content.CursorLoader
import androidx.loader.content.Loader


class MainActivity : AppCompatActivity() {
    companion object {
        private const val CP_AUTHORITY = "pt.isec.ans.teocontentprovider.cp"
        private const val CP_URI = "content://$CP_AUTHORITY"

        private const val TAG = "TstContentProvider"
        private const val LOADER_ID = 1234
    }
    private lateinit var tv : TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tv = findViewById(R.id.tvText)

        // Descomentar o sleep no content provider para verificar a diferença entre as duas versões
        //query_v1()
        query_v2()

    }

    fun query_v1() {
        val uri = Uri.parse("$CP_URI/distrito") // content://pt.isec.ans.teocontentprovider.cp/distrito
        val cursor = contentResolver.query(uri, null,null,
            null,null)

        updateData(cursor)
    }

    fun query_v2() {
        val loader = object:LoaderCallbacks<Cursor> {
            override fun onCreateLoader(id: Int, args: Bundle?): Loader<Cursor> {
                Log.i(TAG, "onCreateLoader: $id")
                val uri = Uri.parse("$CP_URI/distrito") // content://pt.isec.ans.teocontentprovider.cp/distrito
                return CursorLoader(this@MainActivity,
                    uri, null,null, null,null)
            }

            override fun onLoadFinished(loader: Loader<Cursor>, data: Cursor?) {
                Log.i(TAG, "onLoadFinished: ${loader.id}")

                updateData(data)
            }

            override fun onLoaderReset(loader: Loader<Cursor>) {
                Log.i(TAG, "onLoaderReset: ")
            }
        }
        LoaderManager.getInstance(this).initLoader(LOADER_ID,null,loader)
    }

    private fun updateData(data : Cursor?) {
        data?.use {
            it.moveToFirst()
            val sb = StringBuilder("Distritos:\n")
            while (!it.isAfterLast) {
                val _id = it.getLong(0)
                val code= it.getString(1)
                val name= it.getString(2)
                sb.append("Distrito: [$_id/$code] $name\n")
                it.moveToNext()
            }
            tv.text = sb.toString()
        }
    }
}
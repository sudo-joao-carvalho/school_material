package pt.isec.ans.teotstcp

import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.loader.app.LoaderManager
import androidx.loader.content.CursorLoader
import androidx.loader.content.Loader
import pt.isec.ans.teotstcp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    companion object {
        private const val CP_AUTHORITY = "pt.isec.ans.teocontentprovider.cp"
        private const val CP_URI = "content://$CP_AUTHORITY"

        private const val TAG = "TstContentProvider"
        private const val LOADER_ID = 1234
    }
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Descomentar o sleep no content provider para verificar a diferença entre as duas versões
        //query_v1()
        query_v2()

    }

    fun query_v1() {
        val uri = Uri.parse("$CP_URI/distrito") // content://pt.isec.ans.teocontentprovider.cp/distrito
        val cursor = contentResolver.query(uri, null,null,
            null,null)

        updateData(cursor)
    }

    fun query_v2() {
        val loader = object: LoaderManager.LoaderCallbacks<Cursor> {
            override fun onCreateLoader(id: Int, args: Bundle?): Loader<Cursor> {
                Log.i(TAG, "onCreateLoader: $id")
                val uri = Uri.parse("$CP_URI/distrito") // content://pt.isec.ans.teocontentprovider.cp/distrito
                return CursorLoader(this@MainActivity,
                    uri, null,null, null,null)
            }

            override fun onLoadFinished(loader: Loader<Cursor>, data: Cursor?) {
                Log.i(TAG, "onLoadFinished: ${loader.id}")

                updateData(data)
            }

            override fun onLoaderReset(loader: Loader<Cursor>) {
                Log.i(TAG, "onLoaderReset: ")
            }
        }
        LoaderManager.getInstance(this).initLoader(LOADER_ID,null,loader)
    }

    private fun updateData(data : Cursor?) {
        data?.use {
            it.moveToFirst()
            val sb = StringBuilder("Distritos:\n")
            while (!it.isAfterLast) {
                val _id = it.getLong(0)
                val code= it.getString(1)
                val name= it.getString(2)
                sb.append("Distrito: [$_id/$code] $name\n")
                it.moveToNext()
            }
            binding.tvText.text = sb.toString()
        }
    }
}
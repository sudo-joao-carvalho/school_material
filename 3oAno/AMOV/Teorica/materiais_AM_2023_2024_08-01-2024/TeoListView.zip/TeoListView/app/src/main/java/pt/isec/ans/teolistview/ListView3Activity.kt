package pt.isec.ans.teolistview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.SimpleAdapter
import kotlinx.android.synthetic.main.activity_list_view.*
import kotlin.math.log
import kotlin.random.Random

class ListView3Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list_view)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.subtitle = "Exemplo 3"

        val paises = resources.getStringArray(R.array.dados_str)
        paises.sort()
        /*
        val data1 = mapOf("valor1" to 10, "valor2" to 20)
        val data2 = mapOf("valor1" to 11, "valor2" to 21)
        val data = mutableListOf(data1,data2)
        */

        val data = mutableListOf<Map<String,Any>>()

        //val i = Random.nextInt(10,20)
        for(p in paises) {
            val item = mapOf<String,Any>(
                "valor1" to p,
                "valor2" to Random.nextInt(100000,99000000),
                "imagem" to android.R.drawable.ic_menu_compass)
            data.add(item)
        }
        val adapter = SimpleAdapter(this,
            data,R.layout.listview_item,
            arrayOf("valor1","valor2","imagem"),
            intArrayOf(R.id.tv1,R.id.tv2,R.id.ivImg) )
        lvList.adapter = adapter

        lvList.setOnItemClickListener() {
            parent, view, pos, id ->

            Log.i(TAG, "Item: $pos $id")

        }
    }
}
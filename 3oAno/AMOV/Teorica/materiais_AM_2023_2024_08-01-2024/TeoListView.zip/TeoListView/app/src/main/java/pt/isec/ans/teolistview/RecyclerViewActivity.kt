package pt.isec.ans.teolistview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import kotlinx.android.synthetic.main.activity_recycler_view.*
import kotlin.random.Random

class RecyclerViewActivity : AppCompatActivity() {
    data class Dados(val str1:String,val str2 : String, val str3:String)
    val data = arrayListOf<Dados>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recycler_view)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.subtitle = "Example of Recycler View"


        repeat(Random.nextInt(20,150)) {
            val item = Dados(
                str1 = "Title ${Random.nextInt(0,1000)}",
                str2 = getStr(50,400),
                str3 = getStr(5,20)
            )
            data.add(item)
        }

        //rvList.layoutManager = LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false)
        //rvList.layoutManager = LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false)
        //rvList.layoutManager = GridLayoutManager(this,2,GridLayoutManager.VERTICAL,false)
        rvList.layoutManager = StaggeredGridLayoutManager(2,StaggeredGridLayoutManager.VERTICAL)
        rvList.adapter = MyRVAdapter(data)
    }

    fun getStr(minc:Int,maxc: Int) : String {
        var str = ""
        val nrc = Random.nextInt(minc,maxc)
        repeat(nrc) {
            str += Random.nextInt(65,90).toChar()
        }
        return str
    }

    class MyRVAdapter(val data : ArrayList<Dados>)
        : RecyclerView.Adapter<MyRVAdapter.MyViewHolder>() {
        class MyViewHolder(val view : View) : RecyclerView.ViewHolder(view) {
            var tv1 : TextView = view.findViewById(R.id.tv1)
            var tv2 : TextView = view.findViewById(R.id.tv2)
            var tv3 : TextView = view.findViewById<TextView?>(R.id.tv3).apply {
                setOnClickListener {
                    Log.i(TAG, "RecyclerAdapter: Test $text")
                }
            }

            fun update(data : Dados) {
                tv1.text = data.str1
                tv2.text = data.str2
                tv3.text = data.str3 + view.tag
            }
        }

        //override fun getItemId(position: Int): Long = position.toLong()
        override fun getItemViewType(position: Int): Int = when(position) {
            in 5..10 -> 1
            else -> 0
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
            val view = when(viewType) {
                1 ->LayoutInflater.from(parent.context).inflate(R.layout.recyclerview_item_2,parent,false)
                else ->LayoutInflater.from(parent.context).inflate(R.layout.recyclerview_item_1,parent,false)

            }
            view.tag =" "+(nr++)
            return MyViewHolder(view)
        }

        override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
            holder.update(data[position])
        }

        override fun getItemCount(): Int = data.size

        companion object {
            var nr = 0
        }
    }

}
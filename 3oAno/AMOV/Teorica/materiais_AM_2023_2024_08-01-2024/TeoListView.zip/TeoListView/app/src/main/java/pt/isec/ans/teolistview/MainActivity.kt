package pt.isec.ans.teolistview

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View

const val TAG = "ListView"
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Log.i("Teste111", "onCreate: ")
    }

    fun onListView1(view: View) {
        val intent = Intent(this,ListView1Activity::class.java)
        startActivity(intent)
    }

    fun onListView2(view: View) {
        val intent = Intent(this,ListView2Activity::class.java)
        startActivity(intent)
    }
    fun onListView3(view: View) {
        val intent = Intent(this,ListView3Activity::class.java)
        startActivity(intent)
    }

    fun onListView4(view: View) {
        val intent = Intent(this,ListView4Activity::class.java)
        startActivity(intent)
    }
    fun onRecyclerView(view: View) {
        val intent = Intent(this,RecyclerViewActivity::class.java)
        startActivity(intent)
    }
}
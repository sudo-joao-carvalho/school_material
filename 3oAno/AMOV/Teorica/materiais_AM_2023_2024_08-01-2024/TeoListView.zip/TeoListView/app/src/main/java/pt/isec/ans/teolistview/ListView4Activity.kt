package pt.isec.ans.teolistview

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import kotlinx.android.synthetic.main.activity_list_view.*
import kotlin.random.Random

class ListView4Activity : AppCompatActivity() {
    data class Pais (val nome : String, var habitantes:Int)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list_view)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.subtitle = "Exemplo 4"

        val paises = resources.getStringArray(R.array.dados_str)
        paises.sort()
        val data = arrayListOf<Pais>()
        for(p in paises) {
            val item = Pais(p,
                Random.nextInt(100000,99000000))
            data.add(item)
        }

        val adapter = MyAdapter(data)
        lvList.adapter = adapter

        lvList.setOnItemClickListener() {
            parent, view, pos, id ->
            Log.i(TAG, "Item: $pos $id")

        }
    }

    class MyAdapter(val data : ArrayList<Pais>) : BaseAdapter() {
        val imgs = arrayOf(android.R.drawable.ic_menu_agenda,
            android.R.drawable.ic_menu_camera,
                android.R.drawable.ic_menu_call,
            android.R.drawable.ic_menu_compass)

        override fun getCount(): Int = data.size

        override fun getItem(position: Int): Any {
            return data[position]
        }

        override fun getItemId(position: Int): Long = position.toLong()+1000

        override fun getView(
            position: Int,
            convertView: View?,
            parent: ViewGroup?
        ): View {
            val view = LayoutInflater
                .from(parent!!.context)
                .inflate(R.layout.listview_item,parent,false)
            view.findViewById<TextView>(R.id.tv1).text =
                data[position].nome
            view.findViewById<TextView>(R.id.tv2).apply {
                text = data[position].habitantes.toString()
                if (data[position].habitantes > 80000000) {
                    setBackgroundColor(Color.rgb(128,0,0))
                    setTextColor(Color.WHITE)

                }
                setOnClickListener {
                    data[position].habitantes = (data[position].habitantes * 0.5).toInt()
                    this@MyAdapter.notifyDataSetChanged()
                }
                setOnLongClickListener {
                    data[position].habitantes = 99_000_000
                    this@MyAdapter.notifyDataSetChanged()
                    true
                }
            }
            view.findViewById<ImageView>(R.id.ivImg).setImageResource(imgs[Random.nextInt(imgs.size)])
            return view
        }

    }
}
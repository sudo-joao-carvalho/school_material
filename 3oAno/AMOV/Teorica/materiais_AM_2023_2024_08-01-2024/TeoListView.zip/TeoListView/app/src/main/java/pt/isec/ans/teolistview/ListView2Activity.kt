package pt.isec.ans.teolistview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import kotlinx.android.synthetic.main.activity_list_view.*

class ListView2Activity : AppCompatActivity() {
    var flag = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list_view)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.subtitle = "Exemplo 2"

        val paises = resources.getStringArray(R.array.dados_str)
        paises.sort()

        val adapter1 = ArrayAdapter<String>(this,
            R.layout.listview_item,R.id.tv1,paises)
        val adapter2 = ArrayAdapter<String>(this,
            R.layout.listview_item,R.id.tv2,paises)
        lvList.adapter = adapter1

        lvList.setOnItemClickListener() {
            parent, view, pos, id ->
            Log.i(TAG, "Item: $pos $id")
            //adapter1.notifyDataSetChanged()
            lvList.adapter = if (flag) adapter1 else adapter2
            flag = !flag
        }
    }
}
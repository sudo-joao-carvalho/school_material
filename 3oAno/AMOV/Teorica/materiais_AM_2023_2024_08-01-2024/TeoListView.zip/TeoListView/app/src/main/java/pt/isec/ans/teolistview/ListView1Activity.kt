package pt.isec.ans.teolistview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import kotlinx.android.synthetic.main.activity_list_view.*

class ListView1Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list_view)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.subtitle = "Exemplo 1"

        val paises = resources.getStringArray(R.array.dados_str)
        paises.sort()

        val adapter = ArrayAdapter<String>(this,
            android.R.layout.simple_list_item_1,paises)
        lvList.adapter = adapter

        lvList.setOnItemClickListener() {
            parent, view, pos, id ->
            Log.i(TAG, "Item: $pos $id")
        }
    }
}
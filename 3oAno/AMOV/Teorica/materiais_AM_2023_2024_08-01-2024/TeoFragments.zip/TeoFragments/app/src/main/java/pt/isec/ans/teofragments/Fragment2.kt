package pt.isec.ans.teofragments

import android.content.Context
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import pt.isec.ans.teofragments.databinding.Fragment2Binding

interface IFragment2 {
    fun getValue() : Int
}

class Fragment2 : Fragment() {

    lateinit var binding: Fragment2Binding

    var actBase : IFragment2? = null
    //lateinit var tvValue : TextView

    override fun onAttach(context: Context) {
        super.onAttach(context)
        Log.i(TAG, "onAttach2: ")
        actBase = context as? IFragment2
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.i(TAG, "onCreate2: ")
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        Log.i(TAG, "onCreateView2: ")
        /* val view = inflater.inflate(R.layout.fragment_2, container, false)
        tvValue = view.findViewById<TextView>(R.id.tvValue)
        view.findViewById<ImageButton>(R.id.ibRefresh).apply {
            setOnClickListener {
                refresh()
            }
        }
        return view */
        binding = Fragment2Binding.inflate(inflater)
        binding.ibRefresh.setOnClickListener { refresh() }
        return binding.root
    }

    fun refresh() {
        if (actBase == null)
            return
        val value = actBase!!.getValue()
        binding.tvValue.text = "Value: $value"
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        Log.i(TAG, "onActivityCreated2: ")
        refresh()
    }

    override fun onStart() {
        super.onStart()
        Log.i(TAG, "onStart2: ")
    }

    override fun onResume() {
        super.onResume()
        Log.i(TAG, "onResume2: ")
        refresh()
    }

    override fun onPause() {
        super.onPause()
        Log.i(TAG, "onPause2: ")
    }

    override fun onStop() {
        super.onStop()
        Log.i(TAG, "onStop2: ")
    }

    override fun onDestroyView() {
        super.onDestroyView()
        Log.i(TAG, "onDestroyView2: ")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.i(TAG, "onDestroy2: ")
    }
    override fun onDetach() {
        super.onDetach()
        Log.i(TAG, "onDetach2: ")
    }
}

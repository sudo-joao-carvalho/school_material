package pt.isec.ans.teofragments

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner

const val TAG = "TeoFragmentsAMOV"

class MainActivity : AppCompatActivity(),IFragment1,IFragment2 {
    var i = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        Log.i(TAG, "onCreateAa: ")
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Log.i(TAG, "onCreateAz: ")
        this.lifecycle.addObserver(object : LifecycleEventObserver {
            override fun onStateChanged(source: LifecycleOwner, event: Lifecycle.Event) {
                Log.i(TAG, "onStateChanged: ${event.targetState.name}")
            }

        })
    }

    override fun incValue() {
        i++
    }

    override fun getValue(): Int = i

    override fun onStart() {
        Log.i(TAG, "onStartAa: ")
        super.onStart()
        Log.i(TAG, "onStartAz: ")
    }

    override fun onResume() {
        Log.i(TAG, "onResumeAa: ")
        super.onResume()
        Log.i(TAG, "onResumeAz: ")
    }

    override fun onPause() {
        Log.i(TAG, "onPauseAa: ")
        super.onPause()
        Log.i(TAG, "onPauseAz: ")
    }

    override fun onStop() {
        Log.i(TAG, "onStopAa: ")
        super.onStop()
        Log.i(TAG, "onStopAz: ")
    }

    override fun onDestroy() {
        Log.i(TAG, "onDestroyAa: ")
        super.onDestroy()
        Log.i(TAG, "onDestroyAz: ")
    }

    override fun onSaveInstanceState(outState: Bundle) {
        Log.i(TAG, "onSaveInstanceStateAa: ")
        super.onSaveInstanceState(outState)
        outState.putInt("value_i",i)
        Log.i(TAG, "onSaveInstanceStateAz: ")
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        Log.i(TAG, "onRestoreInstanceStateAa: ")
        super.onRestoreInstanceState(savedInstanceState)
        i = savedInstanceState.getInt("value_i",0)
        Log.i(TAG, "onRestoreInstanceStateAz: ")
    }
}
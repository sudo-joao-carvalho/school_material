package pt.isec.ans.teodialogs

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import pt.isec.ans.teodialogs.databinding.ActivityDialogBinding

class DialogActivity : AppCompatActivity() {
    lateinit var binding: ActivityDialogBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDialogBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val title = intent.getStringExtra("title") ?: "AMov"

        this.title = title

        binding.btCancel.setOnClickListener {
            setResult(RESULT_CANCELED)
            finish()
        }
        binding.btLogin.setOnClickListener {
            setResult(RESULT_OK, Intent().apply {
                putExtra("login",binding.edUsername.text.toString())
                putExtra("password",binding.edPassword.text.toString())
            })
            finish()
        }
    }
}
package pt.isec.ans.teodialogs

import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.view.ContextThemeWrapper
import androidx.fragment.app.DialogFragment
import pt.isec.ans.teodialogs.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnDialog1.setOnClickListener {
            dialog1()
        }
        binding.btnDialog2.setOnClickListener {
            dialog2()
        }
        binding.btnDialog3.setOnClickListener {
            dialog3()
        }
    }

    private fun dialog1() {
        //val dialog = AlertDialog.Builder(this)
        val dialog = AlertDialog.Builder(ContextThemeWrapper(this,R.style.MyDialogTheme))
            .setTitle("Title 1")
            //.setMessage("Message 1")
            /*.setSingleChoiceItems(arrayOf("Option 1","Option 2","Option 3"),0) { d,i ->
                toast("dialog1::item $i")
                //d.dismiss()
            }*/
            .setItems(R.array.option_list) { d,i ->
                toast("dialog1::item $i")
            }
            .setIcon(android.R.drawable.ic_dialog_alert)
            .setPositiveButton("Ok")     {d,b -> toast("dialog1::ok")}
            .setNeutralButton("Maybe")   {d,b -> toast("dialog1::maybe")}
            .setNegativeButton("Cancel") {d,b -> toast("dialog1::cancel")}
            .setCancelable(false)
            .create()
        dialog.show()

    }

    class MyDialogFragment: DialogFragment() {
        lateinit var editText: EditText
        override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
            editText = EditText(requireActivity()).apply {
                hint = "write something"
            }
            return AlertDialog.Builder(requireActivity())
                .setTitle("Title 2")
                .setView(editText)
                .setIcon(android.R.drawable.ic_dialog_email)
                .setPositiveButton("Ok") {d,b ->
                    Toast.makeText(requireActivity(),"dialog2::ok ${editText.text}",Toast.LENGTH_LONG).show()
                }
                .setCancelable(true)
                .create()
        }
    }
    private fun dialog2() {
        val dialog = MyDialogFragment()
        dialog.show(supportFragmentManager,"oravla")
    }

    var dialogActivity = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == RESULT_CANCELED) {
            toast("dialog3::cancel")
            return@registerForActivityResult
        }
        val login = it.data?.getStringExtra("login") ?: "none"
        val password = it.data?.getStringExtra("password") ?: "none"
        toast("dialog3::ok $login / $password")
    }

    private fun dialog3() {
        val dlg_intent = Intent(this,DialogActivity::class.java)
        dlg_intent.putExtra("title","DEIS-ISEC")

        //startActivityForResult(dlg_intent,1234)

        dialogActivity.launch(dlg_intent)
    }

    /*override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
    }*/


    fun toast(msg : String) {
        Toast.makeText(this,msg,Toast.LENGTH_LONG).show()
    }
}
package data

// Mixed Product class with size and color
data class MixedProduct(
    override val name: String,
    /* Alínea F */
) : /* Alínea F */, /* Alínea F */ {
    /* Alínea F */
}
package domain

import data.*

typealias ProductCallback = (serialNumber: String) -> Unit

/* Alínea A */ Factory {
    enum class ProductType {
        Size, Color, Mixed
    }

    private val availableProducts = /* Alínea B */
    val products: List<Product>
        get() =  /* Alínea B */

    private var callback: ProductCallback? = null

    fun setProductCallback(callback: ProductCallback) {
        this.callback = callback
    }

    /* Alínea A */ {
        println("Factory has been initialized!")
    }

    fun addProduct(product: Product) {
        // Invoke the callback only if it is not null. (Safe call operator .?)
        /* Alínea C */ callback.invoke(product.serialNumber)
        // Add a product to the catalog.
        /* Alínea C */
    }

    // Factory methods for different product types
    fun createSizeProduct(name: String, price: List<LocalizedPrice>, size: String): Product {
        return SizedProduct(name, Product.generateSerialNumber(SizedProduct.SERIAL_NUMBER_PREFIX), price, size)
    }

    fun createColorProduct(name: String, price: List<LocalizedPrice>, color: String): Product {
        return ColoredProduct(name, Product.generateSerialNumber(ColoredProduct.SERIAL_NUMBER_PREFIX), price, color)
    }

    fun createMixedProduct(name: String, price: List<LocalizedPrice>, size: String, color: String): Product {
        return MixedProduct(name, Product.generateSerialNumber(MixedProduct.SERIAL_NUMBER_PREFIX), price, size, color)
    }

    fun findProduct(serialNumber  /* Alínea G */, name:  /* Alínea G */): Product? {
        return availableProducts.find {
            if (serialNumber != null) {
                it.serialNumber == serialNumber
            } else if (name != null) {
                /* Alínea G */
            } else {
                false
            }
        }
    }

    fun clear() {
        availableProducts.clear()
    }

}

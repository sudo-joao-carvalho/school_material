package data

// Product class with color
data class ColoredProduct(
    override val name: String,
    /* Alínea E */
) : /* Alínea E */, /* Alínea E */ {
    /* Alínea E */
}

package data

// Product class with size
data class SizedProduct(
    override val name: String,
    /* Alínea D */
) : /* Alínea D */, /* Alínea D */ {
    /* Alínea D */
}

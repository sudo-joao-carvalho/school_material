import model.ModelManager;
import resources.ResourceManager;
import java.sql.SQLException;

/*public class Main {
    public static void main(String[] args) throws SQLException {
        ResourceManager resourceManager = new ResourceManager();
        System.out.println(resourceManager.listUsers(-1));
    }
}*/
java -cp "../src" model.client.Client localhost 5001

pause
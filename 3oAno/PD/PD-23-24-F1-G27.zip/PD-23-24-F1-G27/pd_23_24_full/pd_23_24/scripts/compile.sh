javac -d ../out ../src/*.java

pause
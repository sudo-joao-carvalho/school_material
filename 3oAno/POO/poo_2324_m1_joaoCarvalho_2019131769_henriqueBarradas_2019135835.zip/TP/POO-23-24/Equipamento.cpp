//
// Created by João Carvalho on 24/10/2023.
//

#include "Equipamento.h"

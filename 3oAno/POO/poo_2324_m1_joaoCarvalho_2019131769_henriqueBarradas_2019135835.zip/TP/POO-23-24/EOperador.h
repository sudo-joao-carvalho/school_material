//
// Created by João Carvalho on 12/11/2023.
//

#ifndef POO_23_24_EOPERADOR_H
#define POO_23_24_EOPERADOR_H

enum Operador{
    IGUAL_A,
    MENOR_QUE,
    MAIOR_QUE,
    ENTRE,
    FORA
};

#endif //POO_23_24_EOPERADOR_H

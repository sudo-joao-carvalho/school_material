//
// Created by João Carvalho on 21/10/2023.
//

#include "Zona.h"

int Zona::idZona = 0;

Zona::Zona(const int& posX, const int& posY):id(++idZona), posX(posX), posY(posY) {
    propriedades["Temperatura"] = 0;
    propriedades["Luz"] = 0;
    propriedades["Radiacao"] = 0;
    propriedades["Vibracao"] = 0;
    propriedades["Humidade"] = 0;
    propriedades["Fumo"] = 0;
    propriedades["Som"] = 0;
}

Zona::~Zona(){

    for(auto & aparelho : aparelhos){
        delete aparelho;
    }

    for(auto & sensor : sensores){
        delete sensor;
    }

    for(auto & processador : processadores){
        delete processador;
    }
    //idZona = 0;
}

/*Zona& Zona::operator=(const Zona* original) {

    //Prevenir auto-atribuicao
    if(this == original)
        return *this;

    // TODO quando existirem mais atributos na classe zona, deletar o que estiver em memoria dinamica e atribuir corretamente a nova zona

    return *this;
}*/

Aparelho* Zona::adicionaAparelho(const char& tipoDerivado) {

    Aparelho *novoAparelho = nullptr;

    if (tipoDerivado == 'a') {
        novoAparelho = new Aquecedor();
    } else if (tipoDerivado == 's') {
        novoAparelho = new Aspersor();
    } else if (tipoDerivado == 'r') {
        novoAparelho = new Refrigerador();
    } else if (tipoDerivado == 'l') {
        novoAparelho = new Lampada();
    }
    // Se tipoDerivado não for 'a', 's', 'r' ou 'l', novoAparelho permanecerá como nullptr

    if (novoAparelho != nullptr) {
        aparelhos.push_back(novoAparelho);
    }

    return novoAparelho;
}

Sensor* Zona::adicionaSensor(const char& tipoDerivado) {

    Sensor *novoSensor = nullptr;

    switch (tipoDerivado) {
        case 't': // temperatura
            novoSensor = new SensorTemperatura();
            break;
        case 'v': // movimento
            novoSensor = new SensorMovimento();
            break;
        case 'm': // luminosidade
            novoSensor = new SensorLuminosidade();
            break;
        case 'd': // radiacao
            novoSensor = new SensorRadiacao();
            break;
        case 'h': // humidade
            novoSensor = new SensorHumidade();
            break;
        case 'o': // som
            novoSensor = new SensorSom();
            break;
        case 'f': // fumo
            novoSensor = new SensorFumo();
            break;
        default:
            // Tratar o caso em que tipoEquipamento não é reconhecido
            return nullptr;
    }

    if (novoSensor != nullptr) {
        sensores.push_back(novoSensor);
    }

    return novoSensor;
}

bool Zona::removeEquipamento(const char &tipoEquipamento, const int &idEquipamento) {

    if(tipoEquipamento == 'a'){
        for(auto it = aparelhos.begin(); it != aparelhos.end();){
            if ((*it)->getId() == idEquipamento) {
                //da-se delete primeiro do que o erase pq se eu fizesse erase primeiro o erase devolve a posicao do proximo elemento entao se fizessemos delete depois iamos apagar o seguinte e o delete remove o elemento da memoria dinamica entao tem que se dar erase depois para remover a posicao dele no vetor

                delete *it; // Liberta a memória alocada
                it = aparelhos.erase(it); // Remove o elemento do vetor
                return true;
            } else {
                ++it; // Avanca para o próximo elemento
            }
        }

        return false;
    }

    if(tipoEquipamento == 's'){
        for(auto it = sensores.begin(); it != sensores.end();){
            if ((*it)->getId() == idEquipamento) {
                delete *it; // Liberta a memória alocada
                it = sensores.erase(it); // Remove o elemento do vetor
                return true;
            } else {
                ++it; // Avanca para o próximo elemento
            }
        }

        return false;
    }

    if(tipoEquipamento == 'p'){
        for(auto it = processadores.begin(); it != processadores.end();){
            if ((*it)->getId() == idEquipamento) {
                delete *it; // Liberta a memória alocada
                it = processadores.erase(it); // Remove o elemento do vetor
                return true;
            } else {
                ++it; // Avanca para o próximo elemento
            }
        }

        return false;
    }

    return false;
}

//tratamento de propriedades da zona
void Zona::inserePropriedade(const string &key, const int &value) { propriedades[key] = value; }

int Zona::obtemValorPropriedade(const string &key) {
    for(map<string, int>::iterator it = propriedades.begin(); it != propriedades.end();){
        if(it->first == key)
            return it->second;
        else
            ++it;
    }

    return -274; //valor para quando da erro
}

bool Zona::alteraPropriedade(const string& key, const int& value){

    string keyLower = key;
    transform(keyLower.begin(), keyLower.end(), keyLower.begin(), ::tolower);

    for(map<string, int>::iterator it = propriedades.begin(); it != propriedades.end();){

        string currentKeyLower = it->first;
        transform(currentKeyLower.begin(), currentKeyLower.end(), currentKeyLower.begin(), ::tolower);

        if(currentKeyLower == key){
            it->second = value;
            return true;
        }else
            ++it;
    }

    return false;
}

//getters
int Zona::getId() const {return id;}

array<int, 2> Zona::getPosicao() const {return {this->posX, this->posY};}

vector<Aparelho*> Zona::getAparelhos() const {
    return aparelhos;
}

vector<Sensor*> Zona::getSensores() const {
    return sensores;
}

/*vector<Equipamento*> Zona::getEquipamentos() const {return equipamentos;}*/

string Zona::zonaAsString() const {

    ostringstream oss;

    oss << endl << "Zona: " << id << endl
        << "Numero de Aparelhos: " << aparelhos.size() << endl
        << "Numero de Sensores: " << sensores.size() << endl
        << "Numero de Processador: " << "0" << endl << endl;


    return oss.str();
}

string Zona::getEquipamentosAsString() const {

    ostringstream oss;

    oss << "Zona: " << id << endl;

    for(Aparelho* a: aparelhos){
        oss << "Tipo: a" << a->getEquipamentoAsString() << endl;
    }

    /*for(Processador* s: processadores){
        oss << "Zona: " << id << endl
            << "Tipo: p" << p->getEquipamentoAsString() << endl;
        break;
    }*/

    for(Sensor* s: sensores){
        oss << "Tipo: s" << s->getEquipamentoAsString() << endl;
    }

    return oss.str();

}

string Zona::listaPropriedades() const {
    ostringstream oss;

    oss << "Zona: " << id << endl;

    for(map<string, int>::const_iterator it = propriedades.cbegin(); it != propriedades.cend(); ++it){
        oss << "\tPropriedade: " << it->first << "   Valor: " << it->second << endl;
    }

    return oss.str();
}

Neste ficheiro encontra uma descrição do conteúdo da pasta "Template4LaTeX4ISEC" e uma descrição dos primeiros passos para começar a escrever o seu trabalho de licenciatura em LaTeX.

Nesta pasta encontra dois ficheiros ZIP.
O ficheiro "ISEC LaTeX Template (LIC).zip" é o template (isto é, o projeto com o esqueleto de base) e o ficheiro "ISEC LaTeX Exemplo (LIC).zip" é um projeto exemplo personalizado com um nome diferente, onde está descrito como iniciar um novo projeto (a partir da página 8) e onde estão incluídos exemplos de escrita em LaTeX. 
Nesta pasta encontra ainda dois ficheiros PDF que correspondem à versão impressa de cada um dos projetos mencionados.

Recomenda-se, em primeiro lugar, a leitura do ficheiro "ISEC LaTeX Exemplo (LIC).pdf", pois neste ficheiro encontra toda a informação que necessita para avançar com a escrita do seu trabalho de licenciatura em LaTeX.

Bom Trabalho!
